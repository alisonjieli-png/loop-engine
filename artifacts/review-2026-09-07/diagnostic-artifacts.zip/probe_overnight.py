"""Read-only repository review probes; all writes are temporary fixtures."""
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

from core.admission import admit_reply
from core.opencode_step_session import (
    ModelAuthority, ModelGatewayResult, ModelInvocationRequest, OpenCodeStepSession,
)
from core.prompt_transport import BlobStore
from core.recursive_solver import RecursiveSolver, NodeContextStore
from core.runtime_config import RuntimeProfile
from core.step_state import initial_state
from core.typed_memory import TypedMemoryStore
from core.run_history import HistoryDB


class EchoSession:
    model = "fixture/base"
    calls_used = 0
    authority = ModelAuthority(max_model_calls=4)

    def __init__(self):
        self.results = []

    def invoke(self, request, parent_loop=None):
        self.calls_used += 1
        self.results.append(ModelGatewayResult(owner=request.owner, text=request.prompt))
        return request.prompt


results = {}
with tempfile.TemporaryDirectory(prefix="review-overnight-") as root:
    ws = Path(root)
    profile = RuntimeProfile(response_formats=False, horizon_prompts=False,
                             ledger_pull=False, context_budget=False,
                             model_tiers=False, completion_signal=False,
                             auditor=False, memory=False)
    store = NodeContextStore(ws / "context.db")
    solver = RecursiveSolver(ws, EchoSession(), store, "review", profile=profile)
    with patch("core.recursive_solver.render_step_prompt", return_value='{"hypothesis":"echoed untrusted claim"}'), \
         patch("core.recursive_solver.attach_handoff", side_effect=lambda prompt, *_: prompt):
        result = solver._run_node("p0", "orienter", None,
                                  initial_state("fixture task", "false"), "", 0)
    rows = list(store.conn.execute("SELECT kind,status FROM nodes"))
    results["admission"] = {"rows": rows,
                            "hypothesis_after": result["state"].get("hypothesis")}
    results["profile_memory_false"] = {"configured": profile.memory,
                                        "effective": solver.memory_enabled}

    typed = TypedMemoryStore(ws / "typed.db")
    history = HistoryDB(ws / "history.db")
    try:
        typed.mine_procedure(history)
        results["procedural_mining"] = "no error"
    except Exception as exc:
        results["procedural_mining"] = {"error_type": type(exc).__name__, "message": str(exc)}
    typed.propose_fact("fixture fact", source_run="producer")
    promoted = typed.promote_fact("", reviewer="")
    results["empty_reviewer_promotion"] = {"promoted": promoted, "served": typed.truth()}
    typed.close()
    history.close()

    seen = []
    def transport(cmd, env, timeout):
        seen.append(cmd)
        return json.dumps({"type":"text", "part":{"text":"{}"}})
    session = OpenCodeStepSession(authority=ModelAuthority(2), blob_store=BlobStore(ws / "blobs"),
                                  model="fixture/base", transport=transport)
    req = ModelInvocationRequest(prompt="fixture", owner="route-review", workdir=ws,
                                 metadata={"model_tier":"fixture/strong"})
    session.invoke(req)
    cmd = seen[0]
    results["model_tier"] = {"requested_metadata": req.metadata["model_tier"],
                              "launched_model": cmd[cmd.index("-m") + 1]}

    from core.node_package import ENV_PACKAGE_VAR
    deliveries = {}
    for mechanism in ("env", "stdin", "ledger-ref"):
        payload = "review-fixture-package-content"
        calls = []
        def capture_transport(cmd, env, timeout):
            calls.append({"argv_contains_payload":any(payload in arg for arg in cmd),
                          "environment_contains_package":ENV_PACKAGE_VAR in env,
                          "transport_positional_arguments":3})
            return json.dumps({"type":"text", "part":{"text":"{}"}})
        sess = OpenCodeStepSession(authority=ModelAuthority(2),
                                  blob_store=BlobStore(ws / (mechanism + "-blobs")),
                                  model="fixture/base", transport=capture_transport,
                                  package_mechanism=mechanism)
        try:
            sess.invoke(ModelInvocationRequest(prompt=payload, owner="transport-review", workdir=ws))
            deliveries[mechanism] = calls
        except Exception as exc:
            deliveries[mechanism] = {"error":type(exc).__name__, "message":str(exc)}
    results["transport_arms"] = deliveries

print(json.dumps(results, indent=2))

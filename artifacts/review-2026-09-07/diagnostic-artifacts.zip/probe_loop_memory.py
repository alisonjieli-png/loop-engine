"""Check learned-memory status and retrieval behavior on disposable fixtures."""
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from loop_engine.code_nodes.solve_learned_memory import learned_memory_for_solve
from loop_engine.memory.model.memory_type import MemoryScope
from loop_engine.memory.storage.learning_cycle import CandidateJournal
from loop_engine.memory.storage.learning_cycle_checks import _candidate, _promote
from loop_engine.memory.storage.learning_records import LearningPolicy
from loop_engine.reachability_report import reachability_report

results = {"reachability": reachability_report()}
results["reachability"].pop("by_component", None)
with tempfile.TemporaryDirectory(prefix="review-loop-memory-") as root:
    journal = CandidateJournal(Path(root) / "learning")
    _promote(journal, LearningPolicy(allowed_scopes=(MemoryScope.PROJECT,)),
             _candidate("memory-fixture", "predict target column", "benefits from",
                        "a stratified split", evidence="fixture:review"), label="review")
    req = SimpleNamespace(runs_dir=root, intake=SimpleNamespace(original_input="render HTML calendar"))
    result = learned_memory_for_solve(req)
    results["unrelated_claim"] = {"status":result["status"], "selected_ids":[r["record_id"] for r in result["selected"]]}
    with patch.object(Path, "is_file", return_value=True), \
         patch.object(Path, "stat", side_effect=PermissionError("fixture denied")):
        try:
            results["journal_stat_failure"] = learned_memory_for_solve(req)
        except Exception as exc:
            results["journal_stat_failure"] = {"escaped":type(exc).__name__}
print(json.dumps(results, indent=2))

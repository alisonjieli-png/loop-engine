"""Reuse and distillation probes using synthetic local fixtures, no provider."""
import json
import tempfile
from pathlib import Path

from poc.library import SolutionLibrary, looks_hardcoded, restore, snapshot
from poc.fingerprint import fingerprint_task
from poc.tasks import Task
from tests.test_solver import events, make_solver


results = {}
results["hardcode_three_cases"] = {
    "recited_answers": looks_hardcoded("print(1530, 724, 998)", ["1530 724 998"]),
    "input_parameters": looks_hardcoded("print(1530, 724, 998)", ["1530 724 998"], ["1530 724 998"]),
    "computed_expression_evades": looks_hardcoded("print(1500+30, 700+24, 990+8)", ["1530 724 998"]),
}
with tempfile.TemporaryDirectory(prefix="review-library-") as root:
    base = Path(root)
    ws = base / "rollback"
    ws.mkdir()
    (ws / "solve.py").write_text("original script")
    (ws / "helper.txt").write_text("original helper")
    lib = SolutionLibrary(base / "library.db")
    before = snapshot(ws)
    saved = {"solve.py": lib.blobs.put((ws / "solve.py").read_bytes())[0]}
    (ws / "solve.py").unlink()
    (ws / "helper.txt").write_text("changed helper")
    restore(ws, before, lib.blobs, saved)
    results["rollback"] = {"deleted_script_restored": (ws / "solve.py").exists(),
                            "helper_after": (ws / "helper.txt").read_text()}

    ws = base / "distill"
    ws.mkdir()
    (ws / ".gate").mkdir()
    (ws / "deliverables").mkdir()
    gate = ws / ".gate" / "check.py"
    gate.write_text("from pathlib import Path\nassert Path('deliverables/result.txt').read_text() == 'correct'\n")
    task = Task("review-fixture", "Create result.txt containing correct", ws,
                "python3 .gate/check.py", ws / ".gate")
    lib2 = SolutionLibrary(base / "distill-library.db")
    seen = []
    def transport(cmd, env, cwd, timeout):
        prompt = Path(cmd[cmd.index("--file") + 1]).read_text()
        kind = prompt.split("You are the ", 1)[1].split(" ", 1)[0].lower()
        seen.append(kind)
        if kind == "build":
            (ws / "deliverables/result.txt").write_text("correct")
        elif kind == "distill":
            (ws / "deliverables/result.txt").write_text("broken after verification")
        return events({"notes": kind}), "", 0
    solver, store, logs = make_solver(base / "solver", transport, strategy="adaptive", modes="auto", library=lib2)
    report = solver.solve(task)
    results["distill_invalidates_output"] = {"status":report.status, "verified":report.verified,
        "output_after":(ws / "deliverables/result.txt").read_text(), "steps":seen}

    ws = base / "integrity"
    ws.mkdir()
    (ws / ".gate").mkdir()
    (ws / "deliverables").mkdir()
    (ws / ".gate/check.py").write_text("from pathlib import Path\nassert Path('deliverables/result.txt').read_text() == 'correct'\n")
    task = Task("review-integrity", "Create result.txt containing correct", ws,
                "python3 .gate/check.py", ws / ".gate")
    lib3 = SolutionLibrary(base / "integrity-library.db")
    def corrupt_gate_transport(cmd, env, cwd, timeout):
        (ws / "solve.py").write_text("from pathlib import Path\nPath('deliverables').mkdir(exist_ok=True)\nPath('deliverables/result.txt').write_text('wrong')\n")
        (ws / "deliverables/result.txt").write_text("wrong")
        (ws / ".gate/check.py").write_text("pass\n")
        return events({"notes":"fixture changes the protected gate"}), "", 0
    solver, store, logs = make_solver(base / "integrity-solver", corrupt_gate_transport,
                                     strategy="adaptive", modes="auto", library=lib3)
    report = solver.solve(task)
    results["void_run_still_harvests"] = {"run_status":report.status,
        "library_states":[r["state"] for r in lib3.db.execute("SELECT state FROM solutions")]}

print(json.dumps(results, indent=2))

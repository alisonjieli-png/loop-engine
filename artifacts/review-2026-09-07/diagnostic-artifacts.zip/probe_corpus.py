"""Run two copied benchmark gates against positive and negative controls."""
import csv
import ast
import json
import shutil
import subprocess
import tempfile
from pathlib import Path

corpus = Path("/home/username/overnight/tasks")
results = {}
malformed = []
for path in sorted(corpus.glob("*/*.csv")):
    if path.name not in {"train.csv", "test.csv", "sample_submission.csv", "inventory.csv"}:
        continue
    with path.open() as handle:
        header = next(csv.reader(handle), [])
    if header and header[0].startswith("["):
        malformed.append(path)
results["malformed_csv_files"] = {"count":len(malformed),
    "tasks":len({p.parent for p in malformed}), "first":str(malformed[0].relative_to(corpus))}
with tempfile.TemporaryDirectory(prefix="review-corpus-") as root:
    root = Path(root)
    source = sorted(corpus.glob("*-file-transform"))[0]
    ws = root / "transform"
    shutil.copytree(source, ws)
    gate_text = (ws / "gate.sh").read_text()
    import re
    threshold = int(re.search(r"\['qty'\] <= (\d+)", gate_text)[1])
    with (ws / "inventory.csv").open() as handle:
        raw_rows = list(csv.reader(handle))
    names = ["name", "qty", "category"]
    results["transform_original_header_valid"] = raw_rows[0] == names
    # Reconstruct the intended rows from the generator's misplaced first row.
    # This only repairs the disposable control fixture, never the repository.
    rows = [dict(zip(names, ast.literal_eval(item))) for item in raw_rows[0]]
    for row in rows:
        row["stock_status"] = "low" if int(row["qty"]) <= threshold else "ok"
    with (ws / "cleaned.csv").open("w") as handle:
        writer = csv.DictWriter(handle, names + ["stock_status"])
        writer.writeheader()
        writer.writerows(rows)
    (ws / "summary.md").write_text(f"Rows: {len(rows)}; low: {sum(r['stock_status']=='low' for r in rows)}\n")
    result = subprocess.run(["bash", "gate.sh"], cwd=ws, capture_output=True, text=True, timeout=30)
    results["valid_transform"] = {"task":source.name, "exit":result.returncode, "stderr_tail":result.stderr[-650:]}

    source = sorted(corpus.glob("*-tabular-ml"))[0]
    ws = root / "ml"
    shutil.copytree(source, ws)
    with (ws / "sample_submission.csv").open() as handle:
        raw = next(csv.reader(handle))
    # Correct the same generator defect in this disposable fixture to isolate
    # whether the gate tests model training or predictive performance.
    with (ws / "sample_submission.csv").open("w") as handle:
        writer = csv.writer(handle)
        writer.writerow(["id", "target"])
        writer.writerows(ast.literal_eval(item) for item in raw)
    shutil.copyfile(ws / "sample_submission.csv", ws / "submission.csv")
    (ws / "dummy.py").write_text("pass\n")
    result = subprocess.run(["bash", "gate.sh"], cwd=ws, capture_output=True, text=True, timeout=30)
    results["untrained_dummy_predictions_after_fixture_schema_repair"] = {"task":source.name, "exit":result.returncode, "stdout":result.stdout.strip()}
print(json.dumps(results, indent=2))

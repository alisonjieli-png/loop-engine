"""Bounded probe of the open step profile, with no model or effects."""
import json
from loop_engine.loop.recursive_loop import Loop, LoopConfig, StepOutcome

loop = Loop("open profile that never succeeds", LoopConfig(
    framework="open", allowable_modes=("deterministic",),
    preferred_modes=("deterministic",), exit_condition="accepted_success",
    power="light"))
count = 0
def fail(active, step, context):
    global count
    count += 1
    return StepOutcome(output=f"failure {count}", mode="deterministic",
                       confidence=0.0, failed=True)

for _ in range(50):
    if loop.is_terminal:
        break
    loop.run_next_iteration(handler=fail, chooser=lambda _: "attempt")
print(json.dumps({"attempts":count, "terminal":loop.is_terminal,
                  "declared_unaccepted_pass_ceiling":loop.config.supervision.unaccepted_passes_before_stop}))
if not loop.is_terminal:
    loop.cancel("review probe completed")

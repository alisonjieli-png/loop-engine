"""Model-led diagnosis and strategy mutation for stalled work.

Deterministic supervision emits a stall signal. This module asks separate
model steps to diagnose the failure, propose any useful changed strategies,
and adjudicate one recovery directive. The directive is passive data; the
normal Practitioner decision and capability validation path remains
authoritative.
"""
from __future__ import annotations

import json
from dataclasses import dataclass

from .adaptive_practitioner_records import (
    AdaptivePractitionerError, AdaptiveRunServices, ModelStepRequest)
from .adaptive_practitioner_validation import _short_strings, _short_text
from .model_response_admission import ModelResponseContract, ModelResponseAdmissionPolicy


RECOVERY_ROUTES = (
    "continue", "retry", "repair", "explore_branch", "reframe",
    "soft_reset", "cold_restart", "stop_unprofitable")
RECOVERY_CHANGE_KINDS = (
    "configure", "modify", "mutate", "compose", "repair", "research",
    "reframe", "delegate")
@dataclass(frozen=True)
class RecoveryPanelRequest:
    """One stall signal plus the safe state visible to the panel."""

    stall_signal: dict
    model_state: dict
    pass_number: int


def _diagnosis_schema() -> str:
    return json.dumps({
        "diagnosis_id": "string",
        "root_causes": [{
            "cause": "string", "evidence_refs": ["string"],
            "confidence": 0.0}],
        "failed_strategy": "string",
        "missing_context": ["string"],
        "invalid_assumptions": ["string"],
        "recommended_change_types": [
            "configure|mutate|compose|research|reframe|delegate"],
    }, separators=(",", ":"))


def _proposal_schema() -> str:
    return json.dumps({"proposals": [{
        "proposal_id": "unique string",
        "change_kind": (
            "configure|modify|mutate|compose|repair|research|reframe|delegate"),
        "route": "|".join(RECOVERY_ROUTES),
        "directive": "string",
        "required_capabilities": ["registered capability ref"],
        "expected_progress": "string",
        "risks": ["string"],
        "confidence": 0.0,
    }]}, separators=(",", ":"))


def _adjudication_schema() -> str:
    return json.dumps({
        "selected_proposal_id": "string",
        "reason": "string",
        "confidence": 0.0,
    }, separators=(",", ":"))


def _response_contract(identity, properties):
    """Explicit response fields, never executable rules inferred from prose."""
    return ModelResponseContract(identity, json.dumps({
        'type':'object','required':list(properties),'properties':properties},sort_keys=True),
        policy=ModelResponseAdmissionPolicy(report_required_field_names=True))


def _diagnosis_contract():
    text={'type':'string','minLength':1}
    texts={'type':'array','items':text}
    return _response_contract('recovery_diagnosis/v1',{
        'diagnosis_id':text,'root_causes':{'type':'array','minItems':1,'items':{
            'type':'object','required':['cause','evidence_refs','confidence'],
            'properties':{'cause':text,'evidence_refs':texts,
                          'confidence':{'type':'number','minimum':0,'maximum':1}}}},
        'failed_strategy':text,'missing_context':texts,'invalid_assumptions':texts,
        'recommended_change_types':{'type':'array','minItems':1,'items':{'enum':list(RECOVERY_CHANGE_KINDS)}}})


def _proposal_contract(services):
    text={'type':'string','minLength':1}
    refs=sorted(item['capability_ref'] for item in services.available_capabilities())
    properties={'proposal_id':text,'change_kind':{'enum':list(RECOVERY_CHANGE_KINDS)},
        'route':{'enum':list(RECOVERY_ROUTES)},'directive':text,'expected_progress':text,
        'required_capabilities':{'type':'array','items':{'enum':refs} if refs else False},
        'risks':{'type':'array','items':text},'confidence':{'type':'number','minimum':0,'maximum':1}}
    return _response_contract('recovery_proposals/v1',{'proposals':{'type':'array','minItems':1,
        'items':{'type':'object','required':list(properties),'properties':properties}}})


def _adjudication_contract(proposal_ids):
    return _response_contract('recovery_selection/v1',{
        'selected_proposal_id':{'enum':list(proposal_ids)},
        'reason':{'type':'string','minLength':1},
        'confidence':{'type':'number','minimum':0,'maximum':1}})


def _validate_diagnosis(value: dict) -> dict:
    diagnosis_id = _short_text(
        value.get("diagnosis_id"), "diagnosis_id", 120)
    roots = value.get("root_causes")
    if not isinstance(roots, list) or not roots:
        raise AdaptivePractitionerError(
            "recovery diagnosis needs at least one evidenced root cause")
    normalized = []
    for item in roots:
        if not isinstance(item, dict):
            raise AdaptivePractitionerError("root cause must be an object")
        normalized.append({
            "cause": _short_text(item.get("cause"), "root cause"),
            "evidence_refs": list(_short_strings(
                item.get("evidence_refs") or [], "evidence_refs")),
            "confidence": float(item.get("confidence", 0.0)),
        })
    changes = tuple(value.get("recommended_change_types") or ())
    if not changes or any(item not in RECOVERY_CHANGE_KINDS for item in changes):
        raise AdaptivePractitionerError(
            "diagnosis recommended unregistered change types")
    return {
        "diagnosis_id": diagnosis_id,
        "root_causes": normalized,
        "failed_strategy": _short_text(
            value.get("failed_strategy"), "failed_strategy"),
        "missing_context": list(_short_strings(
            value.get("missing_context") or [], "missing_context")),
        "invalid_assumptions": list(_short_strings(
            value.get("invalid_assumptions") or [], "invalid_assumptions")),
        "recommended_change_types": list(changes),
    }


def _validate_proposal(value: dict, services: AdaptiveRunServices) -> dict:
    route = str(value.get("route") or "")
    change_kind = str(value.get("change_kind") or "")
    if change_kind not in RECOVERY_CHANGE_KINDS:
        raise AdaptivePractitionerError("recovery proposal is not registered")
    if route not in RECOVERY_ROUTES:
        raise AdaptivePractitionerError(
            "recovery proposal route is not registered")
    capabilities = tuple(value.get("required_capabilities") or ())
    registered = {item["capability_ref"]
                  for item in services.available_capabilities()}
    if set(capabilities) - registered:
        raise AdaptivePractitionerError(
            "recovery proposal names an unavailable capability")
    return {
        "proposal_id": _short_text(
            value.get("proposal_id"), "proposal_id", 120),
        "change_kind": change_kind,
        "route": route,
        "directive": _short_text(
            value.get("directive"), "recovery directive"),
        "required_capabilities": list(capabilities),
        "forbidden_action_kinds": [],
        "expected_progress": _short_text(
            value.get("expected_progress"), "expected_progress"),
        "risks": list(_short_strings(value.get("risks") or [], "risks")),
        "confidence": float(value.get("confidence", 0.0)),
    }


def _validate_proposals(value: dict, services: AdaptiveRunServices) -> tuple:
    raw = value.get("proposals")
    if not isinstance(raw, list) or not raw:
        raise AdaptivePractitionerError(
            "recovery needs at least one executable changed strategy")
    proposals = tuple(_validate_proposal(item, services)
                      for item in raw if isinstance(item, dict))
    if len(proposals) != len(raw):
        raise AdaptivePractitionerError(
            "every recovery proposal must be an object")
    identities = [item["proposal_id"] for item in proposals]
    if len(identities) != len(set(identities)):
        raise AdaptivePractitionerError("recovery proposal identities repeat")
    signatures = {
        (item["change_kind"], tuple(item["required_capabilities"]),
         item["directive"])
        for item in proposals}
    if len(signatures) != len(proposals):
        raise AdaptivePractitionerError(
            "recovery proposals must contain materially different changes")
    return proposals


def _resolve_validated_step(
        services: AdaptiveRunServices, step_id: str, objective: str,
        state: dict, schema: str, validator, admission_contract=None):
    """Give one rejected semantic result a bounded typed repair attempt."""
    failure = ""
    rejected = None
    for attempt in (1, 2):
        directive = (objective if attempt == 1 else
                     "Repair the rejected recovery result without changing "
                     "the task, authority, or requested schema.")
        value = services.model(ModelStepRequest(
            step_id, directive,
            {**state, "recovery_validation_failure": failure,
             "rejected_recovery_output": rejected}, schema,
            admission_contract=admission_contract))
        try:
            return validator(value)
        except (AdaptivePractitionerError, TypeError, ValueError) as exc:
            failure = str(exc)[:500]
            rejected = value
            services.diagnostic("recovery_step_invalid", {
                "step_id": step_id, "attempt": attempt, "error": failure})
    raise AdaptivePractitionerError(
        f"recovery step {step_id} remained invalid after one repair: {failure}")


def resolve_stall_with_panel(
        request: RecoveryPanelRequest,
        services: AdaptiveRunServices) -> dict:
    """Run diagnosis, proposal generation, and a separate adjudication."""
    common = {
        **request.model_state,
        "stall_signal": request.stall_signal,
        "pass_number": request.pass_number,
        "prior_recovery_directives": services.recovery_directives,
    }
    diagnosis = _resolve_validated_step(
        services, "diagnose_stall",
        "Diagnose why governed work stopped making useful progress.",
        common, _diagnosis_schema(), _validate_diagnosis, _diagnosis_contract())
    proposal_values = _resolve_validated_step(
        services, "propose_recovery",
        "Propose every useful executable changed strategy from the diagnosis. "
        "Do not repeat the same change under different wording.",
        {**common, "diagnosis": diagnosis}, _proposal_schema(),
        lambda value: _validate_proposals(value, services), _proposal_contract(services))
    proposals = {item["proposal_id"]: item for item in proposal_values}

    def validate_adjudication(raw_value):
        selected = _short_text(
            raw_value.get("selected_proposal_id"),
            "selected_proposal_id", 120)
        if selected not in proposals:
            raise AdaptivePractitionerError(
                f"recovery adjudication selected proposal {selected!r}, "
                f"which was not offered; the offered proposals are "
                f"{list(proposals)[:24]}")
        reason = _short_text(
            raw_value.get("reason"), "recovery reason")
        confidence = float(raw_value.get("confidence", 0.0))
        if not 0.0 <= confidence <= 1.0:
            raise AdaptivePractitionerError(
                "recovery adjudication confidence must be from zero to one")
        return reason, confidence, selected

    adjudication_reason, adjudication_confidence, selected_id = (
        _resolve_validated_step(
        services, "adjudicate_recovery",
        "Select one recovery directive using evidence, progress, authority, and risk.",
        {**common, "diagnosis": diagnosis,
         "proposals": list(proposal_values)},
        _adjudication_schema(), validate_adjudication, _adjudication_contract(proposals)))
    adjudicated = proposals[selected_id]
    directive = {
        "record_type": "practitioner_recovery_directive/v1",
        "recovery_round": services.recovery_rounds + 1,
        "stall_signal": request.stall_signal,
        "diagnosis": diagnosis,
        "proposals": list(proposal_values),
        "selected_proposal_id": selected_id,
        "route": adjudicated["route"],
        "reason": adjudication_reason,
        "directive": adjudicated["directive"],
        "required_capabilities": adjudicated["required_capabilities"],
        "forbidden_action_kinds": adjudicated["forbidden_action_kinds"],
        "expected_progress": adjudicated["expected_progress"],
        "confidence": adjudication_confidence,
    }
    services.recovery_rounds += 1
    services.unchanged_progress_snapshots = 0
    services.recovery_directives.append(directive)
    services.active_recovery_directive = directive
    if getattr(getattr(services,'request',None), 'capture_recovery_learning', False):
        from .recovery_learning import capture_recovery_learning
        from ..loop.kernel_runtime import current_kernel_owner
        try:
            directive['learning_capture'] = capture_recovery_learning(
                directive, services, parent=current_kernel_owner())
        except Exception as exc:
            # Candidate extraction cannot invent a lesson or promote a failed
            # result. The original recovery and shared accounting remain intact.
            directive['learning_capture'] = {'record_type':'recovery_learning_capture/v1',
                'disposition':'unavailable','error_type':type(exc).__name__,
                'active_intelligence_updated':False,'improvement_demonstrated':False}
            services.diagnostic('recovery_learning_unavailable',{'error_type':type(exc).__name__})
    return directive


def recover_step_contract_failure(failure, model_state, services):
    """Reorient before an action when an enabled response-repair cycle stalls.

    The panel uses separate cognitive assignments. Its own failure is reported
    once and is not recursively sent into this handler. No failed response is
    converted into a valid action or an accepted task result.
    """
    from .model_response_admission import ModelResponseRepairStalled
    if not isinstance(failure, ModelResponseRepairStalled):
        raise TypeError('step recovery requires an observed typed response stall')
    if not getattr(getattr(services,'request',None),'diagnose_unchanged_evidence',False):
        raise failure
    results=getattr(getattr(services,'model_session',None),'results',())
    admissions=getattr(results[-1],'response_admissions',()) if results else ()
    signal={'record_type':'practitioner_stall_signal/v2','code':'RECOVERY_DIAGNOSIS_REQUIRED',
        'trigger':'response_contract_stalled','phase':'before_action',
        'step_id':failure.step_id,'attempts':failure.attempts,'failure_code':failure.failure_code,
        'rejected_digests':list(failure.rejected_digests),
        'schema_errors':sorted({message for item in admissions for message in item.schema_errors}),
        'diagnosis_only':True,'current_action_executed':False}
    services.supervision_findings.append(signal)
    services.diagnostic('step_contract_reorientation_required',signal)
    try:
        return resolve_stall_with_panel(RecoveryPanelRequest(
            signal,model_state,int(getattr(services,'active_pass_number',0))),services)
    except Exception as exc:
        services.diagnostic('step_contract_reorientation_unavailable',{
            'step_id':failure.step_id,'error_type':type(exc).__name__})
        return None

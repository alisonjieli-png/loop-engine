"""Run the operator-declared verifier script as a mid-solve observation.

Only the explicit ``verifier_path`` on the run request ever executes:
nothing is discovered, inferred, or defaulted. The verifier runs with
its parent directory as cwd (so a task gate sees its data and the run's
solution), a bounded timeout, and a minimal environment. Its exit code
and output tail return as an observation for replanning; a passing gate
never accepts the task by itself — acceptance stays with verification.
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

VERIFIER_RECORD_TYPE = "verifier_execution/v1"
DEFAULT_TIMEOUT_SECONDS = 600.0
MAX_OUTPUT_BYTES = 8192


class VerifierError(ValueError):
    """The declared verifier cannot be run as specified."""


def verifier_execute_operation(arguments, services) -> dict:
    """Execute the declared verifier script, returning score evidence."""
    request = getattr(services, "request", None)
    declared = str(getattr(request, "verifier_path", "") or "").strip()
    if not declared:
        raise VerifierError(
            "no verifier declared: mid-solve verification needs an "
            "explicit operator-declared verifier path")
    candidate = Path(declared)
    if not candidate.is_absolute():
        candidate = Path(os.getcwd()) / candidate
    try:
        resolved = candidate.resolve(strict=False)
    except OSError as exc:
        raise VerifierError(
            f"verifier path does not resolve: {declared!r}") from exc
    if not resolved.is_file():
        raise VerifierError(
            f"verifier is not a file: {declared!r}")
    timeout = (arguments or {}).get("timeout_seconds",
                                    DEFAULT_TIMEOUT_SECONDS)
    if (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
            or not timeout > 0 or timeout > 3600):
        raise VerifierError(
            "verifier timeout_seconds must be within (0, 3600]")
    env = {"PATH": "/usr/bin:/bin:/usr/local/bin",
           "HOME": os.environ.get("HOME", "/tmp")}
    try:
        completed = subprocess.run(
            ["bash", str(resolved)], cwd=str(resolved.parent),
            capture_output=True, text=True, timeout=float(timeout),
            env=env)
    except subprocess.TimeoutExpired as exc:
        raise VerifierError(
            f"verifier exceeded {timeout:g}s; partial output retained") from exc
    except OSError as exc:
        raise VerifierError(
            f"verifier launch failed: {type(exc).__name__}") from exc
    combined = (completed.stdout or "") + (completed.stderr or "")
    tail = combined.strip().splitlines()[-12:]
    return {
        "record_type": VERIFIER_RECORD_TYPE,
        "verifier": str(resolved),
        "exit_code": completed.returncode,
        "passed": completed.returncode == 0,
        "timeout_seconds": float(timeout),
        "output_tail": tail,
        "note": ("observation for replanning only: a passing gate does "
                 "not accept the task"),
    }


def self_test() -> dict:
    """Offline verifier-operation checks; the script fixtures are local."""
    import tempfile
    results = []

    def check(name, ok, detail=""):
        results.append({"test": name, "passed": bool(ok), "detail": detail})

    class _Services:
        def __init__(self, path):
            self.request = type("Request", (),
                                {"verifier_path": path})()

    with tempfile.TemporaryDirectory(prefix="verifier-op-") as folder:
        passing = Path(folder) / "gate-pass.sh"
        passing.write_text("#!/bin/bash\necho 'holdout metric = 0.9900 (floor 0.1000)'\n",
                           encoding="utf-8")
        failing = Path(folder) / "gate-fail.sh"
        failing.write_text("#!/bin/bash\necho 'holdout metric = 0.0100'\nexit 3\n",
                           encoding="utf-8")
        ok_result = verifier_execute_operation(
            {}, _Services(str(passing)))
        check("passing_verifier_returns_score_evidence",
              ok_result["passed"] is True and ok_result["exit_code"] == 0
              and any("0.9900" in line
                      for line in ok_result["output_tail"]),
              "exit code plus output tail, never acceptance")
        bad_result = verifier_execute_operation(
            {}, _Services(str(failing)))
        check("failing_verifier_returns_failure_as_observation",
              bad_result["passed"] is False and bad_result["exit_code"] == 3)
        missing = False
        try:
            verifier_execute_operation(
                {}, _Services(str(Path(folder) / "absent.sh")))
        except VerifierError:
            missing = True
        check("missing_verifier_path_is_refused", missing)
        undeclared = False
        try:
            verifier_execute_operation({}, _Services("   "))
        except VerifierError:
            undeclared = True
        check("undeclared_verifier_never_runs_anything", undeclared)
        slow = Path(folder) / "gate-slow.sh"
        slow.write_text("#!/bin/bash\nsleep 30\n", encoding="utf-8")
        timed_out = False
        try:
            verifier_execute_operation({"timeout_seconds": 1},
                                       _Services(str(slow)))
        except VerifierError:
            timed_out = True
        check("verifier_timeout_is_bounded_and_typed", timed_out)
    passed = sum(1 for item in results if item["passed"])
    return {"tests": results, "passed": passed, "total": len(results),
            "all_passed": passed == len(results)}

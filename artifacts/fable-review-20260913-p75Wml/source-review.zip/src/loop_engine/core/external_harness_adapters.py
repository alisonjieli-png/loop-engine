"""Optional adapters for four external agent harnesses.

Adapters expose one common Loop Engine request and result while importing each
framework only when selected. External packages are not core dependencies.
Every adapter also accepts an injected runner for deterministic conformance
tests and application-specific SDK configuration.

Pydantic AI, OpenAI Agents, and Microsoft Agent Framework receive the exact
resolved output allowance at their documented SDK boundaries. Deep Agents
requires a provider-bound model whose typed binding records that the same
maximum was applied before the graph was created. No path installs packages,
chooses credentials, approves effects, or claims task acceptance.
"""
from __future__ import annotations

import asyncio
import importlib.metadata
import importlib.util
import inspect
import json
from dataclasses import dataclass
from typing import Callable, Mapping

from .external_harness import (
    HarnessAdapterInfo, HarnessError, HarnessModelCall, HarnessRunRequest,
    HarnessRunResult, HarnessRuntimeBinding, HarnessServices, ModelOutputLimit,
    resolve_harness_output_limit)
from .harness_execution_contracts import (
    SDK_FRAMEWORKS as _FRAMEWORKS,
    HarnessExecutionCapabilities, plain_harness_json, unmet_harness_requirements,
)

RunnerFn = Callable[[HarnessRunRequest, HarnessServices], object]


@dataclass(frozen=True)
class _AdapterExecution:
    """Raw SDK result plus the capacity backing the applied output allowance."""

    raw: object
    applied_output_limit: "ModelOutputLimit | None" = None
    prompt_resource: object = None

def _instruction_resource(harness_id: str):
    from ..strings.prompt_fragments import external_harness_instruction_bundle
    return external_harness_instruction_bundle(harness_id).render(
        {}, provenance={})

class PhysicalCallCountingClient:
    """Count and stop calls at an SDK client's provider request boundary."""

    def __init__(self, client, *, max_calls: "int | None" = None):
        if not callable(getattr(client, "get_response", None)):
            raise TypeError("counted chat client needs get_response")
        if (max_calls is not None
                and (not isinstance(max_calls, int)
                     or isinstance(max_calls, bool) or max_calls < 1)):
            raise ValueError("max_calls must be a positive integer")
        self._client = client
        self._max_calls = max_calls
        self.call_count = 0

    @property
    def additional_properties(self):
        return getattr(self._client, "additional_properties", {})

    def get_response(self, *args, **kwargs):
        if (self._max_calls is not None
                and self.call_count >= self._max_calls):
            raise HarnessError(
                "external harness model-call budget is exhausted")
        self.call_count += 1
        return self._client.get_response(*args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._client, name)

def _package_state(harness_id: str, injected: bool) -> tuple[bool, str, str]:
    facts = _FRAMEWORKS[harness_id]
    if injected:
        return True, "injected", ""
    if importlib.util.find_spec(facts["module"]) is None:
        return False, "", (
            f"optional package {facts['package']!r} is not installed")
    try:
        version = importlib.metadata.version(facts["package"])
    except importlib.metadata.PackageNotFoundError:
        version = "unknown"
    if not facts["output_limit_binding"]:
        return False, version, (
            "package detected, but the built-in adapter has no verified exact "
            "maximum-output binding and will not execute")
    return True, version, ""

def _prompt(request: HarnessRunRequest) -> str:
    payload = json.dumps(plain_harness_json(request.input_data),
                         sort_keys=True, allow_nan=False)
    return (
        f"Goal: {request.goal}\n"
        f"Input contract: {list(request.contract.input_roles)}\n"
        f"Output contract: {list(request.contract.output_roles)}\n"
        f"Context references: {list(request.context_refs)}\n"
        f"Input data: {payload}\n"
        "Return the requested result. Do not claim verification or acceptance; "
        "the spawning Loop performs the independent evaluation."
    )

def _required_output_limit(request: HarnessRunRequest) -> ModelOutputLimit:
    limit = request.budget.output_limit
    if limit is None:
        raise HarnessError(
            "adapter execution needs a resolved exact model output maximum")
    if (limit.provider_id != request.provider_id
            or limit.model_id != request.model_id):
        raise HarnessError(
            "resolved model output maximum does not match provider and model")
    return limit

def _required_runtime_binding(
        request: HarnessRunRequest, services: HarnessServices, *,
        runtime_kind: str,
        preconfigured_output_limit: bool = False) -> HarnessRuntimeBinding:
    binding = services.runtime_binding
    if binding is None:
        raise HarnessError(
            "package-backed harness execution needs a typed, provider-bound "
            "HarnessRuntimeBinding")
    binding.validate_for(
        request, runtime_kind=runtime_kind,
        preconfigured_output_limit=preconfigured_output_limit)
    return binding

def _openai_model_settings_kwargs(request: HarnessRunRequest) -> dict:
    _required_output_limit(request)
    return {
        "max_tokens": request.budget.requested_output_tokens,
        "temperature": float(request.metadata.get("temperature", 0.2)),
        "include_usage": True,
    }

def _pydantic_model_settings_kwargs(request: HarnessRunRequest) -> dict:
    _required_output_limit(request)
    settings = {
        "max_tokens": request.budget.requested_output_tokens,
        "temperature": float(request.metadata.get("temperature", 0.2)),
    }
    if request.budget.max_seconds is not None:
        settings["timeout"] = float(request.budget.max_seconds)
    return settings

def _pydantic_usage_limit_kwargs(request: HarnessRunRequest) -> dict:
    values = {"request_limit": request.budget.max_model_calls}
    if request.budget.max_total_tokens is not None:
        values["total_tokens_limit"] = request.budget.max_total_tokens
    return values

def _deep_agents_graph_config(request: HarnessRunRequest) -> dict:
    # LangGraph counts graph steps rather than physical model calls. The
    # preconfigured model binding remains responsible for the physical limit.
    if request.budget.max_model_calls is None:
        raise HarnessError("unbounded Deep Agents recursion is not qualified")
    return {"recursion_limit": max(4, request.budget.max_model_calls * 4 + 2)}

def _microsoft_harness_kwargs(
        request: HarnessRunRequest, counted_client: object) -> dict:
    _required_output_limit(request)
    return {
        "client": counted_client,
        "disable_web_search": True,
        "disable_file_memory": True,
        "disable_compaction": True,
        "disable_todo": True,
        "disable_mode": True,
        "disable_tool_auto_approval": True,
        "max_output_tokens": request.budget.requested_output_tokens,
    }

def _resolve_output_request(
        request: HarnessRunRequest,
        services: HarnessServices) -> HarnessRunRequest:
    return resolve_harness_output_limit(request, services)

def _value(source, names, default=None):
    for name in names:
        if isinstance(source, Mapping) and name in source:
            return source[name]
        if hasattr(source, name):
            value = getattr(source, name)
            try:
                return value() if callable(value) else value
            except TypeError:
                continue
    return default

def _int_value(source, names) -> "int | None":
    value = _value(source, names)
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None

def _float_value(source, names) -> "float | None":
    value = _value(source, names)
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None

def _message_usage(raw, request: HarnessRunRequest
                   ) -> tuple[list[HarnessModelCall], int]:
    messages = _value(raw, ("messages",), ()) or ()
    calls = []
    for message in messages:
        usage = _value(message, ("usage_metadata", "usage"), None)
        if usage is None:
            continue
        input_tokens = _int_value(
            usage, ("input_tokens", "prompt_tokens", "request_tokens"))
        output_tokens = _int_value(
            usage, ("output_tokens", "completion_tokens", "response_tokens"))
        response = _value(message, ("response_metadata",), {}) or {}
        model = str(_value(response, ("model_name", "model"), "")
                    or request.model_id)
        calls.append(HarnessModelCall(
            provider=request.provider_id, model=model, ok=True,
            input_tokens=input_tokens, output_tokens=output_tokens))
    return calls, len(calls)

def _normalize(raw, request: HarnessRunRequest, *,
               adapter_version: str,
               applied_output_limit: "ModelOutputLimit | None" = None,
               prompt_resource=None,
               ) -> HarnessRunResult:
    if isinstance(raw, HarnessRunResult):
        if raw.provider_id and raw.provider_id != request.provider_id:
            raise HarnessError("adapter result changed provider_id")
        if raw.model_id and raw.model_id != request.model_id:
            raise HarnessError("adapter result changed model_id")
        raw.provider_id = request.provider_id
        raw.model_id = request.model_id
        if any(call.provider != request.provider_id
               for call in raw.model_calls):
            raise HarnessError(
                "adapter result model-call provider does not match provider_id")
        claimed = (
            raw.max_output_tokens_used is not None
            or bool(raw.model_output_limit_source)
            or bool(raw.model_output_limit_reference))
        limit = applied_output_limit
        if limit is not None:
            _required_output_limit(request)
            if limit != request.budget.output_limit:
                raise HarnessError(
                    "adapter applied a different model output maximum")
            if (claimed and (
                    raw.max_output_tokens_used != request.budget.requested_output_tokens
                    or raw.model_output_limit_source != limit.source
                    or raw.model_output_limit_reference != limit.reference)):
                raise HarnessError(
                    "adapter output-limit record contradicts the applied limit")
            raw.max_output_tokens_used = request.budget.requested_output_tokens
            raw.model_output_limit_source = limit.source
            raw.model_output_limit_reference = limit.reference
        elif claimed:
            expected = _required_output_limit(request)
            if (raw.max_output_tokens_used != request.budget.requested_output_tokens
                    or raw.model_output_limit_source != expected.source
                    or raw.model_output_limit_reference != expected.reference):
                raise HarnessError(
                    "injected runner reported a mismatched output limit")
        if prompt_resource is not None:
            raw.prompt_resource_ref = prompt_resource.bundle_ref
            raw.prompt_resource_digest = prompt_resource.bundle_digest
            raw.prompt_slot_schema_digest = prompt_resource.slot_schema_digest
            raw.prompt_render_digest = prompt_resource.render_digest
        return raw
    output = _value(raw, ("final_output", "output", "data", "text"), None)
    if output is None and isinstance(raw, Mapping):
        messages = raw.get("messages") or ()
        if messages:
            output = _value(messages[-1], ("content", "text"), messages[-1])
    if output is None:
        output = raw

    usage = _value(raw, ("usage", "usage_details"), None)
    if usage is None:
        context_wrapper = _value(raw, ("context_wrapper",), None)
        usage = _value(context_wrapper, ("usage",), None)
    input_tokens = _int_value(
        usage, ("input_tokens", "prompt_tokens", "request_tokens",
                "input_token_count"))
    output_tokens = _int_value(
        usage, ("output_tokens", "completion_tokens", "response_tokens",
                "output_token_count"))
    requests = _int_value(
        usage, ("requests", "request_count", "model_requests", "calls"))
    cost = _float_value(usage, ("cost", "total_cost", "cost_usd"))
    message_calls, message_count = _message_usage(raw, request)
    if requests is None and message_count:
        requests = message_count
    calls = tuple(message_calls)
    if requests == 1 and not calls:
        calls = (HarnessModelCall(
            provider=request.provider_id, model=request.model_id, ok=True,
            input_tokens=input_tokens, output_tokens=output_tokens, cost=cost),)
    count_complete = requests is not None
    limit = applied_output_limit
    if limit is not None:
        expected = _required_output_limit(request)
        if limit != expected:
            raise HarnessError(
                "adapter applied a different model output maximum")
    result = HarnessRunResult(
        request_id=request.request_id, harness_id=request.harness_id,
        status="completed", output=output, model_calls=calls,
        adapter_version=adapter_version, provider_id=request.provider_id,
        model_id=request.model_id,
        call_count_complete=count_complete,
        reported_model_call_count=requests,
        aggregate_input_tokens=input_tokens,
        aggregate_output_tokens=output_tokens,
        aggregate_cost=cost,
        max_output_tokens_used=(request.budget.requested_output_tokens if limit else None),
        model_output_limit_source=(limit.source if limit else ""),
        model_output_limit_reference=(limit.reference if limit else ""))
    if prompt_resource is not None:
        result.prompt_resource_ref = prompt_resource.bundle_ref
        result.prompt_resource_digest = prompt_resource.bundle_digest
        result.prompt_slot_schema_digest = prompt_resource.slot_schema_digest
        result.prompt_render_digest = prompt_resource.render_digest
    return result

@dataclass
class ConfiguredHarnessAdapter:
    """Base adapter with an optional injected runner."""

    harness_id: str
    runner: "RunnerFn | None" = None
    adapter_version: str = "1.0.0"

    def __post_init__(self) -> None:
        if self.harness_id not in _FRAMEWORKS:
            raise ValueError(f"unknown external harness {self.harness_id!r}")

    def info(self) -> HarnessAdapterInfo:
        available, package_version, reason = _package_state(
            self.harness_id, self.runner is not None)
        facts = _FRAMEWORKS[self.harness_id]
        features = tuple(facts["features"])
        limitations = list(facts["limitations"])
        if self.runner is not None:
            features = ("typed_request", "normalized_result",
                        "injected_runner")
            limitations = [
                "an injected runner is application code, not package-backed "
                "runtime integration proof",
                "normalization records an output limit only when the runner "
                "returns a matching typed record",
            ]
        else:
            limitations.append(
                "package detection alone is not package-backed runtime "
                "integration proof")
            if not available:
                limitations.append(
                    "package-backed runtime integration is unproven in this "
                    "installation")
        return HarnessAdapterInfo(
            harness_id=self.harness_id,
            adapter_version=self.adapter_version,
            package_name=facts["package"], package_version=package_version,
            features=features,
            limitations=tuple(limitations), available=available,
            availability_reason=reason,
            execution_capabilities=HarnessExecutionCapabilities(
                supported_features=("context_refs",), isolation="none",
                evidence_refs=("source:core.external_harness_adapters",)))

    def run(self, request: HarnessRunRequest,
            services: HarnessServices) -> HarnessRunResult:
        if request.harness_id != self.harness_id:
            raise HarnessError("adapter identity does not match request")
        missing = unmet_harness_requirements(request, self.info().execution_capabilities)
        if self.runner is None:
            unsupported = []
            if (request.budget.max_model_calls is None
                    and self.harness_id in ("deep_agents", "openai_agents")):
                unsupported.append("feature:unbounded_model_calls")
            allocation = request.budget.output_allocation
            if (self.harness_id == "deep_agents" and allocation is not None
                    and allocation.requested_tokens != allocation.maximum_output_tokens):
                unsupported.append("feature:output_allocation")
            missing = (*missing, *unsupported)
        if missing:
            return HarnessRunResult(
                request.request_id, request.harness_id, "refused",
                error_code="harness_capability_requirement_unsatisfied",
                provider_id=request.provider_id, model_id=request.model_id,
                adapter_version=self.adapter_version,
                capability_evaluation={"satisfied": False, "missing": list(missing),
                                       "execution_started": False})
        request = _resolve_output_request(request, services)
        applied_output_limit = None
        prompt_resource = None
        if self.runner is not None:
            raw = self.runner(request, services)
        elif self.harness_id == "pydantic_ai":
            raw = self._run_pydantic(request, services)
        elif self.harness_id == "deep_agents":
            raw = self._run_deep_agents(request, services)
        elif self.harness_id == "openai_agents":
            raw = self._run_openai_agents(request, services)
        else:
            raw = self._run_microsoft(request, services)
        if isinstance(raw, _AdapterExecution):
            applied_output_limit = raw.applied_output_limit
            prompt_resource = raw.prompt_resource
            raw = raw.raw
        return _normalize(
            raw, request, adapter_version=self.adapter_version,
            applied_output_limit=applied_output_limit,
            prompt_resource=prompt_resource)

    @staticmethod
    def _run_pydantic(request: HarnessRunRequest,
                      services: HarnessServices):
        limit = _required_output_limit(request)
        binding = _required_runtime_binding(
            request, services, runtime_kind="model")
        from pydantic_ai import Agent, ModelSettings, UsageLimits

        instruction = _instruction_resource("pydantic_ai")

        agent = Agent(
            binding.runtime_object,
            instructions=instruction.text)
        raw = agent.run_sync(
            _prompt(request),
            model_settings=ModelSettings(
                **_pydantic_model_settings_kwargs(request)),
            usage_limits=UsageLimits(
                **_pydantic_usage_limit_kwargs(request)))
        return _AdapterExecution(raw, limit, instruction)

    @staticmethod
    def _run_deep_agents(request: HarnessRunRequest,
                         services: HarnessServices):
        limit = _required_output_limit(request)
        binding = _required_runtime_binding(
            request, services, runtime_kind="model",
            preconfigured_output_limit=True)
        from deepagents import create_deep_agent

        instruction = _instruction_resource("deep_agents")

        agent = create_deep_agent(
            model=binding.runtime_object,
            tools=[],
            system_prompt=instruction.text,
            subagents=[], skills=[], memory=[], permissions=[],
            checkpointer=False)
        raw = agent.invoke(
            {"messages": [{"role": "user", "content": _prompt(request)}]},
            config=_deep_agents_graph_config(request))
        return _AdapterExecution(raw, limit, instruction)

    @staticmethod
    def _run_openai_agents(request: HarnessRunRequest,
                           services: HarnessServices):
        limit = _required_output_limit(request)
        binding = _required_runtime_binding(
            request, services, runtime_kind="model")
        from agents import Agent, ModelSettings, RunConfig, Runner

        instruction = _instruction_resource("openai_agents")

        agent = Agent(
            name="Loop Engine external specialist",
            instructions=instruction.text,
            model=binding.runtime_object)
        raw = Runner.run_sync(
            agent, _prompt(request), max_turns=request.budget.max_model_calls,
            run_config=RunConfig(
                tracing_disabled=True,
                model_settings=ModelSettings(
                    **_openai_model_settings_kwargs(request))))
        return _AdapterExecution(raw, limit, instruction)

    @staticmethod
    def _run_microsoft(request: HarnessRunRequest,
                       services: HarnessServices):
        limit = _required_output_limit(request)
        binding = _required_runtime_binding(
            request, services, runtime_kind="client")
        from agent_framework import create_harness_agent

        client = binding.runtime_object
        counted_client = PhysicalCallCountingClient(
            client, max_calls=request.budget.max_model_calls)
        agent = create_harness_agent(
            **_microsoft_harness_kwargs(request, counted_client))
        session = agent.create_session()
        run_sync = getattr(agent, "run_sync", None)
        if callable(run_sync):
            response = run_sync(_prompt(request), session=session)
            return _AdapterExecution(
                ConfiguredHarnessAdapter._microsoft_result(
                    response, counted_client), limit)
        value = agent.run(_prompt(request), session=session)
        if inspect.isawaitable(value):
            try:
                asyncio.get_running_loop()
            except RuntimeError:
                response = asyncio.run(value)
                return _AdapterExecution(
                    ConfiguredHarnessAdapter._microsoft_result(
                        response, counted_client), limit)
            raise RuntimeError(
                "Microsoft synchronous adapter cannot run inside an active "
                "event loop; inject an async application runner")
        return _AdapterExecution(
            ConfiguredHarnessAdapter._microsoft_result(
                value, counted_client), limit)

    @staticmethod
    def _microsoft_result(response, client):
        usage = getattr(response, "usage_details", None) or {}
        count = None
        for name in ("model_call_count", "call_count", "calls"):
            value = getattr(client, name, None)
            if isinstance(value, int):
                count = value
                break
            if isinstance(value, (list, tuple)):
                count = len(value)
                break
        normalized_usage = dict(usage)
        if count is not None:
            normalized_usage["requests"] = count
        return {"output": getattr(response, "text", response),
                "usage": normalized_usage}

def builtin_harness_adapters(
        runners: "Mapping[str, RunnerFn] | None" = None
        ) -> tuple[ConfiguredHarnessAdapter, ...]:
    """Create all adapters without importing or registering frameworks."""
    supplied = dict(runners or {})
    return tuple(ConfiguredHarnessAdapter(
        harness_id, runner=supplied.get(harness_id))
                 for harness_id in _FRAMEWORKS)

def self_test() -> dict:
    """Run focused SDK contract checks without importing a provider SDK."""
    from .external_harness_adapter_checks import run_checks
    return run_checks()

"""Command-line interface for Loop Engine.

    PYTHONPATH=. python3 -m loop_engine --self-test
    ... --self-test      # run the deterministic self-test suite
"""

from __future__ import annotations

import argparse
import contextlib
import errno
import json
import sys
import tempfile
import time

from ._self_test import self_test


def _run_self_test_captured(test_fn=self_test) -> tuple[dict, int]:
    """Run noisy folded tests behind a real OS-backed text stream."""
    import threading
    started = time.monotonic()
    finished = threading.Event()

    def heartbeat() -> None:
        while not finished.wait(10):
            elapsed = int(time.monotonic() - started)
            print(f"Self-test still running: {elapsed} seconds elapsed.",
                  file=sys.__stderr__, flush=True)

    monitor = threading.Thread(target=heartbeat, daemon=True)
    monitor.start()
    try:
        with tempfile.TemporaryFile(mode="w+", encoding="utf-8") as stream:
            with contextlib.redirect_stdout(stream), \
                    contextlib.redirect_stderr(stream):
                report = test_fn()
            stream.flush()
            stream.seek(0)
            captured_lines = sum(1 for _line in stream)
    finally:
        finished.set()
        monitor.join(timeout=1)
    return report, captured_lines


def _concise_self_test_summary(
        report: dict, captured_lines: int, elapsed_seconds: float = 0.0) -> dict:
    failures = []
    for item in report.get("tests", ()):
        if item.get("passed"):
            continue
        failures.append({
            "test": item.get("test") or item.get("name") or "unnamed test",
            "detail": str(item.get("detail") or item.get("note") or "")[:300],
            **({"missing_dependency": item["missing_dependency"]}
               if item.get("missing_dependency") else {}),
        })
    return {
        "record_type": "loop_engine_self_test_summary/v1",
        "passed": report.get("passed", 0),
        "total": report.get("total", 0),
        "all_passed": bool(report.get("all_passed")),
        "missing_dependencies": report.get("missing_dependencies", []),
        "optional_adapters_not_tested": report.get(
            "optional_adapters_not_tested", []),
        "captured_output_lines": captured_lines,
        "elapsed_seconds": round(elapsed_seconds, 3),
        "provider_calls_made": 0,
        "failures": failures,
    }


def _render_self_test_summary(summary: dict) -> str:
    lines = [
        "Loop Engine full self-test: "
        + ("PASSED" if summary["all_passed"] else "FAILED"),
        f"Checks: {summary['passed']}/{summary['total']}",
        f"Elapsed: {summary['elapsed_seconds']:.3f} seconds",
        "Provider calls: 0",
    ]
    if summary["missing_dependencies"]:
        lines.append("Missing dependencies: "
                     + ", ".join(summary["missing_dependencies"]))
    if summary["optional_adapters_not_tested"]:
        lines.append(
            "Optional adapters not tested: "
            + ", ".join(summary["optional_adapters_not_tested"])
            + ". Install loop-engine[all] to test them.")
    for failure in summary["failures"]:
        lines.append(
            f"FAILED {failure['test']}: {failure['detail'] or 'no detail'}")
    lines.append("Use --format json for the complete typed summary.")
    return "\n".join(lines)


def _read_task_file(path: str) -> str:
    """Read a task file, refusing missing or unreadable paths."""
    if not path:
        return ""
    import os
    if not os.path.isfile(path):
        print(f"error: task file not found: {path}")
        return ""
    with open(path, encoding="utf-8") as handle:
        return handle.read().strip()


def main(argv=None) -> int:
    from .cli_help import ROOT_HELP, command_help
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    if not raw_argv:
        print(ROOT_HELP)
        return 0
    focused_help = command_help(raw_argv)
    if focused_help:
        print(focused_help)
        return 0
    if raw_argv[:1] == ["records"]:
        from .record_cli import record_command
        return record_command(raw_argv[1:])
    parser = argparse.ArgumentParser(
        prog="loop-engine",
        description=__doc__.splitlines()[0],
        epilog='Solve a task: loop-engine solve --text "your request"')
    test_output = parser.add_mutually_exclusive_group()
    test_output.add_argument(
        "--self-test", action="store_true",
        help="run all tests and print one concise summary plus failures")
    test_output.add_argument(
        "--self-test-verbose", action="store_true",
        help="run all tests with module demo output and the full JSON report")
    parser.add_argument("--categories", action="store_true",
                        help="print the retired resolver category view (empty)")
    parser.add_argument("--map", action="store_true",
                        help="print the nine-step kernel map: where every "
                        "capability lives")
    parser.add_argument("--profiles", action="store_true",
                        help="print the versioned Loop profile catalog")
    parser.add_argument("--doctor", action="store_true",
                        help="check package, architecture, settings, and the "
                             "no-key deterministic lane without network calls")
    parser.add_argument("--configure", action="store_true",
                        help="inspect provider key references and print the "
                             "next exact probe without contacting a provider")
    parser.add_argument("--live-demo", action="store_true",
                        help="watch a real canonical Loop run live: "
                        "localhost page with the step rail + console log "
                        "(deterministic stage-0 fixture, zero model calls)")
    parser.add_argument("--studio", action="store_true",
                        help="serve Loop Engine Studio (local, read-only, "
                        "backed by saved run history) on --port")
    parser.add_argument("--port", type=int,
                        help="local port (Studio defaults to 8765; live demo "
                             "defaults to 8770)")
    parser.add_argument("--runs-dir",
                        help="shared saved-run directory; defaults to "
                             "$LOOP_ENGINE_RUNS_DIR or ~/.loop-engine/runs")
    parser.add_argument("--conformance", action="store_true",
                        help="run the machine-enforced conformance scan + "
                        "zero-tolerance gates; writes "
                        "architecture_conformance.json; exits nonzero on any "
                        "violation")
    parser.add_argument("--structure", action="store_true",
                        help="print the repository structure report")
    parser.add_argument("--structure-json", action="store_true",
                        help="print the repository structure report as JSON")
    parser.add_argument("--repo-conformance", action="store_true",
                        help="run the repository conformance harness")
    parser.add_argument("--plugin-action",
                        choices=("discover", "resolve", "inspect"),
                        help="discover, resolve, or inspect plugin bundles")
    parser.add_argument("--plugin-root", action="append", default=[],
                        help="installed plugin bundle root; repeat as needed")
    parser.add_argument("--project-plugin-root", action="append", default=[],
                        help="project plugin bundle root; repeat as needed")
    parser.add_argument("--skill-root", action="append", default=[],
                        help="skill root used during admitted plugin resolution")
    parser.add_argument("--skill-admission", action="append", default=[],
                        help="SkillAdmissionRecord JSON file; repeat as needed")
    parser.add_argument("--plugin-id", default="",
                        help="exact plugin id for plugin inspect")
    parser.add_argument("--engine-api-version", default="1",
                        help="required plugin engine API version")
    parser.add_argument(
        "--extensions-action",
        choices=("discover", "providers", "capabilities", "intelligence",
                 "plugins", "skills"),
        help="inspect automatically discovered added-file extensions")
    parser.add_argument(
        "--extension-root", action="append", default=[],
        help="added-file extension root; repeat as needed")
    parser.add_argument(
        "--no-default-extensions", action="store_true",
        help="ignore project and user extension folders")
    parser.add_argument(
        "--allow-paid-extension-routes", action="store_true",
        help="allow paid added-file provider routes to enter automatic tiers")
    parser.add_argument("--architecture-contract", action="store_true",
                        help="validate the machine-readable architecture contract")
    parser.add_argument("--task-compile", action="store_true",
                        help=argparse.SUPPRESS)
    parser.add_argument("--task-build", action="store_true",
                        help=argparse.SUPPRESS)
    parser.add_argument(
        "--compile-provider",
        default="",
        help="optionally add one authorized model-assisted Orientation "
             "review; the deterministic compilation remains authoritative. "
             "Builtin providers: ollama_cloud, mistral, openrouter, "
             "opencode_zen, opencode_go. A custom provider id from the "
             "settings file is resolved through its configured routes.")
    parser.add_argument(
        "--provider-key-env", default="", metavar="ENV_NAME",
        help="read the selected provider key from this environment variable; "
             "the key value is never a command argument")
    parser.add_argument(
        "--prompt-for-provider-key", action="store_true",
        help="read the selected provider key through a hidden terminal prompt")
    compile_key_shortcut = parser.add_mutually_exclusive_group()
    compile_key_shortcut.add_argument(
        "--ollama-api-key", nargs="?", const="__prompt__", default=None,
        metavar="VALUE",
        help="accept an Ollama key value, or omit VALUE to use "
             "OLLAMA_API_KEY or a hidden prompt")
    compile_key_shortcut.add_argument(
        "--mistral-api-key", nargs="?", const="__prompt__", default=None,
        metavar="VALUE",
        help="accept a Mistral key value, or omit VALUE to use "
             "MISTRAL_API_KEY or a hidden prompt")
    compile_key_shortcut.add_argument(
        "--openrouter-api-key", nargs="?", const="__prompt__", default=None,
        metavar="VALUE",
        help="accept an OpenRouter key value, or omit VALUE to use "
             "OPENROUTER_API_KEY or a hidden prompt")
    compile_key_shortcut.add_argument(
        "--opencode-zen-api-key", nargs="?", const="__prompt__", default=None,
        metavar="VALUE",
        help="accept an OpenCode Zen key value, or omit VALUE to use "
             "OPENCODE_ZEN_API_KEY or a hidden prompt; selects a current "
             "zero-cost compatible model")
    compile_key_shortcut.add_argument(
        "--opencode-go-api-key", nargs="?", const="__prompt__", default=None,
        metavar="VALUE",
        help="accept an OpenCode Go key value, or omit VALUE to use "
             "OPENCODE_GO_API_KEY or a hidden prompt")
    parser.add_argument(
        "--interaction-mode",
        choices=("ask_when_material", "autonomous"),
        default="ask_when_material",
        help=argparse.SUPPRESS)
    parser.add_argument(
        "--unattended", action="store_true",
        help="do not pause for material answers; abstain instead of guessing")
    parser.add_argument(
        "--quickstart", action="store_true",
        help="use the LLM-first onboarding profile: one detected provider, "
             "LLM-first reasoning, and material clarification questions")
    parser.add_argument(
        "--embodiment", default="",
        help="select an explicitly configured harness for canonical semantic steps")
    parser.add_argument(
        "--embodiment-config", default="",
        help="absolute path to a typed harness embodiment configuration")
    parser.add_argument(
        "--harness-work-dir", default="",
        help="absolute directory for private harness process artifacts")
    parser.add_argument(
        "--harness-socket-dir", default="",
        help="absolute short directory for private local broker sockets")
    parser.add_argument(
        "--allow-model-failover", action="store_true",
        help="permit the same solve to try other exact authorized routes "
             "after a retryable provider or response failure")
    parser.add_argument(
        "--quiet-model-io", action="store_true",
        help="reduce solve progress to event summaries without the exact "
             "prompt and output text; full model IO traces stderr by "
             "default. Run History events store digests in both modes; "
             "the assembled work packets remain in the run's artifact store")
    parser.add_argument(
        "--allow-local-execution", action="store_true",
        help="when Docker is unavailable, permit generated code to run as a "
             "host process without an operating-system sandbox; the run "
             "record labels the weaker isolation. Off by default")
    parser.add_argument(
        "--context-budget-tokens", type=int, metavar="TOKENS",
        help="optional ceiling for the estimated model input of one call; "
             "omitted means the route context window minus the requested "
             "output maximum is the only ceiling. Command output and fetched "
             "text in the Practitioner state are always bounded and recorded")
    parser.add_argument(
        "--practitioner-mode",
        choices=("deterministic", "hybrid", "non_deterministic"),
        default="non_deterministic",
        help=argparse.SUPPRESS)
    parser.add_argument(
        "--max-passes", type=int,
        help="optional ceiling for complete Practitioner passes; omitted "
             "means no product-imposed pass ceiling")
    parser.add_argument(
        "--task-feedback", action="append", default=[], metavar="SLOT=VALUE",
        help="optional registered task feedback slot; repeat when needed")
    parser.add_argument("--text", default="",
                        help="freeform task text for --task-compile or --solve")
    parser.add_argument("--file", default="",
                        help="task instruction file; may be combined with one "
                             "--dataset, --repository, or --url source")
    parser.add_argument("--url", default="",
                        help="URL source for task compilation or solve")
    parser.add_argument("--dataset", default="",
                        help="dataset path; pair with --text for its goal")
    parser.add_argument("--repository", default="",
                        help="repository path; pair with --text for its goal")
    parser.add_argument("--task-pack", default="",
                        help="versioned JSON task-pack path")
    parser.add_argument("--solve", action="store_true",
                        help="solve a task from --text or --file")
    parser.add_argument("--workspace", default="",
                        help="empty or new directory for generated task artifacts")
    parser.add_argument("--verifier", default="",
                        help="explicit verifier script, run mid-solve as an observation")
    parser.add_argument(
        "--allow-source-to-model", action="store_true",
        help="allow supplied dataset or repository text to enter the selected "
             "model context; required for model-backed local-source tasks")
    parser.add_argument("--templates", action="store_true",
                        help="list registered task templates")
    parser.add_argument("--learn", action="store_true",
                        help="stage learning candidates from the latest run")
    parser.add_argument("--lesson", default="",
                        help="evidence-bounded candidate lesson for --learn")
    parser.add_argument("--candidates", action="store_true",
                        help="list staged learning candidates")
    parser.add_argument("--candidate-action",
                        choices=("review", "promote", "rollback"),
                        help="govern one exact learning-candidate version")
    parser.add_argument("--candidate-id", default="")
    parser.add_argument("--candidate-version", default="")
    parser.add_argument("--candidate-digest", default="")
    parser.add_argument("--decision", choices=("accept", "reject"),
                        default="accept")
    parser.add_argument("--decision-reason", default="")
    parser.add_argument("--evidence", action="append", default=[],
                        help="evidence reference; repeat for multiple refs")
    parser.add_argument("--demo", choices=("five-step",),
                        help="run the five-step product demo")
    parser.add_argument("--report", metavar="RUN_ID", nargs="?", const="@last",
                        help="render a loop report for a saved run "
                             "(default: the most recent). Use --format and "
                             "--out to choose the rendering and destination.")
    parser.add_argument("--runs", action="store_true",
                        help="list the saved runs a report can be built from")
    parser.add_argument("--format", default="text",
                        choices=("text", "markdown", "html", "json"),
                        help="report rendering (default: text)")
    parser.add_argument("--out", metavar="PATH",
                        help="write the report to PATH instead of stdout")
    parser.add_argument("--setup", action="store_true",
                        help="guided walkthrough: checks the installation, "
                             "providers, your own server and knowledge, then "
                             "runs a real loop")
    parser.add_argument("--example",
                        choices=("support-queue", "intelligence-layers",
                                 "context-seed"),
                        help="run a useful example included with the package")
    parser.add_argument("--campaign", choices=("plan", "run"),
                        help="plan or run the five-problem pilot campaign")
    parser.add_argument("--verify-live-model", metavar="PROVIDER",
                        help="verify one real Ollama Cloud, Mistral, or custom "
                             "provider call against repository metadata")
    parser.add_argument("--model-route", default="",
                        help="exact route for live verification or "
                             "provider-assisted task compilation")
    parser.add_argument("--model-id", default="",
                        help="exact model for live verification or "
                             "provider-assisted task compilation")
    parser.add_argument("--models-action",
                        choices=("inventory", "routes", "explain", "benchmark"),
                        help="inspect or explain model routing without provider calls")
    parser.add_argument("--model-purpose", default="decide_label",
                        help="gateway purpose for models explain")
    parser.add_argument("--operator", default="",
                        help="task operator override for models explain")
    parser.add_argument("--response-topology", default="",
                        help="response topology override for models explain")
    parser.add_argument("--local-only", action="store_true",
                        help="restrict model selection to local routes")
    parser.add_argument("--deterministic-sufficient", action="store_true",
                        help="declare a source-backed deterministic procedure "
                             "for models explain")
    parser.add_argument("--repository-root", default=".",
                        help="repository whose pyproject.toml is used by the "
                             "live verification")
    parser.add_argument("--live-evidence-out", default="",
                        help="new JSON evidence path; default is a protected "
                             "file below ~/.loop-engine/evidence")
    parser.add_argument("--live-timeout", type=float, default=300.0,
                        help="wall-time limit for the one live provider call")
    parser.add_argument("--settings-action", choices=("init", "show", "check"),
                        help="create, show, or validate user settings")
    parser.add_argument("--settings-file",
                        help="explicit YAML settings path")
    parser.add_argument("--modes", default="",
                        help="comma-separated campaign modes; defaults to "
                             "the user settings")
    parser.add_argument("--providers", default="",
                        help="comma-separated campaign providers; defaults "
                             "to enabled providers in user settings")
    parser.add_argument("--thinking-power", default="",
                        choices=("", "small", "medium", "high", "max",
                                 "specialized"),
                        help="model capacity tier for model-using campaign "
                             "arms")
    parser.add_argument("--cases", default="",
                        help="comma-separated campaign case IDs; default all")
    parser.add_argument("--authorize-model-calls", action="store_true",
                        help="explicitly allow governed model calls")
    parser.add_argument("--max-model-calls", type=int,
                        help="optional physical model-call ceiling")
    parser.add_argument("--max-total-tokens", type=int,
                        help="optional provider-reported token ceiling")
    parser.add_argument("--allow-unbounded-total-tokens", action="store_true",
                        help="explicitly allow the single models probe without a total-token ceiling")
    parser.add_argument("--watch", action="store_true",
                        help="print campaign events while arms run")
    if raw_argv[:1] == ["setup"]:
        raw_argv[:1] = ["--setup"]
    elif raw_argv[:1] == ["configure"]:
        raw_argv[:1] = ["--configure"]
    elif raw_argv[:1] == ["doctor"]:
        raw_argv[:1] = ["--doctor"]
    elif raw_argv[:1] == ["solve"]:
        raw_argv[:1] = ["--solve"]
    elif raw_argv[:1] == ["studio"]:
        raw_argv[:1] = ["--studio"]
    elif raw_argv[:1] == ["runs"]:
        raw_argv[:1] = ["--runs"]
    elif raw_argv[:1] == ["report"]:
        raw_argv[:1] = ["--report"]
    elif raw_argv[:1] == ["templates"]:
        raw_argv[:1] = ["--templates"]
    elif raw_argv[:1] == ["profiles"]:
        raw_argv[:1] = ["--profiles"]
    elif raw_argv[:2] == ["task", "build"]:
        raw_argv[:2] = ["--task-build"]
    elif raw_argv[:2] == ["task", "compile"]:
        raw_argv[:2] = ["--task-compile"]
    elif raw_argv[:2] == ["models", "probe"]:
        if len(raw_argv) < 3 or raw_argv[2].startswith("-"):
            parser.error("models probe requires a provider id")
        raw_argv[:3] = ["--verify-live-model", raw_argv[2]]
    elif raw_argv[:1] == ["models"]:
        if len(raw_argv) < 2 or raw_argv[1] not in (
                "inventory", "routes", "explain", "benchmark"):
            parser.error(
                "models requires inventory, routes, explain, benchmark, or probe")
        raw_argv[:2] = ["--models-action", raw_argv[1]]
    elif raw_argv[:1] == ["extensions"]:
        if len(raw_argv) < 2 or raw_argv[1] not in (
                "discover", "providers", "capabilities", "intelligence",
                "plugins", "skills"):
            parser.error(
                "extensions requires discover, providers, capabilities, "
                "intelligence, plugins, or skills")
        raw_argv[:2] = ["--extensions-action", raw_argv[1]]
    elif raw_argv[:1] == ["learn"]:
        raw_argv[:1] = ["--learn"]
    elif raw_argv[:2] == ["candidates", "list"]:
        raw_argv[:2] = ["--candidates"]
    elif raw_argv[:1] == ["candidates"]:
        if len(raw_argv) < 2 or raw_argv[1] not in (
                "review", "promote", "rollback"):
            parser.error("candidates requires list, review, promote, or rollback")
        raw_argv[:2] = ["--candidate-action", raw_argv[1]]
    elif raw_argv[:1] == ["campaign"]:
        if len(raw_argv) < 2 or raw_argv[1] not in ("plan", "run"):
            parser.error("campaign requires plan or run")
        raw_argv[:2] = ["--campaign", raw_argv[1]]
    elif raw_argv[:1] == ["settings"]:
        if len(raw_argv) < 2 or raw_argv[1] not in ("init", "show", "check"):
            parser.error("settings requires init, show, or check")
        raw_argv[:2] = ["--settings-action", raw_argv[1]]
    elif raw_argv[:1] == ["plugin"]:
        if len(raw_argv) < 2 or raw_argv[1] not in (
                "discover", "resolve", "inspect"):
            parser.error("plugin requires discover, resolve, or inspect")
        raw_argv[:2] = ["--plugin-action", raw_argv[1]]
    args = parser.parse_args(raw_argv)
    if args.allow_unbounded_total_tokens and not args.verify_live_model:
        parser.error("--allow-unbounded-total-tokens applies only to models probe")
    if args.unattended:
        args.interaction_mode = "autonomous"
    if args.doctor:
        from .cli_operations import run_doctor
        return run_doctor(args)
    if args.configure:
        from .cli_operations import run_configure
        return run_configure(args)
    if args.models_action:
        from .cli_operations import run_models_action
        return run_models_action(args)
    if args.extensions_action:
        from .cli_operations import run_extensions_action
        return run_extensions_action(args)
    if args.plugin_action:
        from .cli_operations import run_plugin_action
        return run_plugin_action(args)
    if args.verify_live_model:
        from .core.live_model_verification import (
            LiveModelVerificationError, LiveModelVerificationRequest,
            plan_live_model_verification, run_live_model_verification)
        try:
            request = LiveModelVerificationRequest(
                provider=args.verify_live_model,
                repository_root=args.repository_root,
                settings_file=args.settings_file or "",
                route_name=args.model_route,
                model=args.model_id,
                authorize_model_calls=args.authorize_model_calls,
                max_physical_model_calls=args.max_model_calls or 0,
                max_total_tokens=args.max_total_tokens,
                timeout_seconds=args.live_timeout,
                evidence_path=args.live_evidence_out,
                allow_unbounded_total_tokens=args.allow_unbounded_total_tokens)
            if not args.authorize_model_calls:
                planned = plan_live_model_verification(request).safe_summary()
                planned["status"] = "NOT_RUN"
                planned["reason"] = (
                    "add --authorize-model-calls and --max-model-calls 1; "
                    "choose an explicit --allow-unbounded-total-tokens grant "
                    "or a qualified --max-total-tokens policy")
                print(json.dumps(planned, indent=1))
                return 2
            result = run_live_model_verification(request)
            print(json.dumps(result, indent=1))
            return 0 if result["provider_integration_proven"] else 1
        except (LiveModelVerificationError, KeyError, ValueError) as exc:
            print(json.dumps({
                "record_type": "live_model_verification_refusal/v1",
                "status": "NOT_RUN",
                "provider_integration_proven": False,
                "reason": str(exc),
            }, indent=1))
            return 2
    if args.settings_action:
        from .core.settings_loader import (
            load_runtime_settings, write_default_settings)
        from .core.runtime_settings import SettingsError
        try:
            if args.settings_action == "init":
                created = write_default_settings(args.settings_file)
                value = {"record_type": "settings_created/v1",
                         "path": created.path, "loop_id": created.loop_id}
                print(json.dumps(value, indent=1) if args.format == "json"
                      else f"Created Loop Engine settings at {created.path} "
                      f"through {created.loop_id}")
                return 0
            loaded = load_runtime_settings(args.settings_file)
            summary = loaded.safe_summary()
            if args.settings_action == "check":
                gateway = loaded.settings.build_gateway()
                enabled = set(gateway.providers)
                usable_by_tier = {}
                for tier in loaded.settings.models.tiers:
                    usable = []
                    for route_name in tier.routes:
                        route = gateway.registry.get(route_name)
                        if route.provider in enabled:
                            usable.append(route_name)
                    usable_by_tier[tier.name] = usable
                summary["validation"] = {
                    "valid": True,
                    "network_calls": 0,
                    "usable_routes_by_tier": usable_by_tier,
                }
            print(json.dumps(summary, indent=1))
            return 0
        except (SettingsError, KeyError, ValueError, RuntimeError) as exc:
            value = {"record_type": "settings_error/v1",
                     "error_code": "SETTINGS_INVALID", "error": str(exc)}
            print(json.dumps(value, indent=1) if args.format == "json"
                  else f"Settings refused: {exc}")
            return 2
    if args.campaign:
        from .code_nodes.campaign_runner import (
            CAMPAIGN_MODES, CampaignRunOptions, CampaignRunner, campaign_arms,
            default_campaign_spec, default_problem_cases)
        from .core.settings_loader import load_runtime_settings
        try:
            loaded = load_runtime_settings(args.settings_file)
        except ValueError as exc:
            parser.error(str(exc))
        runtime_settings = loaded.settings
        modes = (tuple(value.strip() for value in args.modes.split(",")
                       if value.strip()) or runtime_settings.loop.preferred_modes)
        providers = (tuple(value.strip()
                           for value in args.providers.split(",")
                           if value.strip())
                     or runtime_settings.models.enabled_provider_ids())
        thinking_power = (args.thinking_power
                          or runtime_settings.models.default_thinking_power)
        all_cases = default_problem_cases()
        requested_cases = {value.strip() for value in args.cases.split(",")
                           if value.strip()}
        cases = tuple(case for case in all_cases
                      if not requested_cases or case.case_id in requested_cases)
        unknown_cases = requested_cases - {case.case_id for case in all_cases}
        if unknown_cases:
            parser.error(f"unknown campaign cases: {sorted(unknown_cases)}")
        bad_modes = [mode for mode in modes if mode not in CAMPAIGN_MODES]
        if bad_modes:
            parser.error(f"unknown campaign modes: {bad_modes}")
        arms = campaign_arms(
            modes=modes, providers=providers,
            llm_thinking_power=thinking_power)
        if args.campaign == "plan":
            model_arms = sum(1 for case in cases
                             for arm in arms
                             if arm.mode != "deterministic")
            print(json.dumps({
                "record_type": "campaign_plan/v1",
                "cases": [case.summary() for case in cases],
                "arms": [arm.arm_id for arm in arms],
                "runs": len(cases) * len(arms),
                "model_arms": model_arms,
                "minimum_model_call_ceiling": model_arms,
                "model_authorization_required": bool(model_arms),
                "llm_thinking_power": thinking_power,
            }, indent=1))
            return 0
        try:
            spec = default_campaign_spec(
                modes=modes, providers=providers,
                llm_thinking_power=thinking_power,
                cases=cases,
                authorize_model_calls=args.authorize_model_calls,
                max_model_calls=args.max_model_calls,
                max_total_tokens=args.max_total_tokens)
        except ValueError as exc:
            print(f"Campaign refused: {exc}")
            return 2
        from .core.run_history import default_runs_dir
        runs_dir = default_runs_dir(
            args.runs_dir or runtime_settings.history.resolved_runs_dir())
        result = CampaignRunner(spec, CampaignRunOptions(
            runs_dir=runs_dir, watch=args.watch,
            runtime_settings=runtime_settings)).run()
        print(json.dumps(result.to_dict(), indent=1))
        return 0 if result.accepted == len(result.arms) else 1
    if args.setup:
        from .code_nodes.guided_setup import run_setup
        if args.format == "json":
            import io
            stream = io.StringIO()
            with contextlib.redirect_stdout(stream):
                report = run_setup(interactive=False)
            value = report.summary()
            value["captured_walkthrough_lines"] = len(
                stream.getvalue().splitlines())
            print(json.dumps(value, indent=1))
        else:
            report = run_setup(interactive=sys.stdin.isatty())
        return 0 if report.ready else 1
    if args.example:
        from .code_nodes.public_examples import run_example
        print(run_example(args.example))
        return 0
    if args.runs or args.report:
        from .run_history_cli import run_history_command
        return run_history_command(args)
    if args.live_demo:
        from .code_nodes.live_run_demo import run_live_demo
        run_live_demo(port=args.port or 8770, pace_seconds=0.6,
                      serve_forever=True, runs_dir=args.runs_dir or "")
        return 0
    if args.studio:
        from .core.studio_server import StudioServeRequest, serve
        selected_port = 8765 if args.port is None else args.port
        try:
            serve(StudioServeRequest(
                port=selected_port, runs_dir=args.runs_dir or ""))
            return 0
        except OSError as exc:
            if getattr(exc, "errno", None) == errno.EADDRINUSE:
                print(
                    f"Studio could not use port {selected_port}: the port is "
                    "already in use. Retry with --port 0 to select a free port.",
                    file=sys.stderr)
                return 2
            raise
    if args.conformance:
        from .conformance_report import run_conformance
        report = run_conformance()
        print(report["human_summary"])
        return 0 if report["all_gates_pass"] else 1
    if args.structure:
        from .repository_structure import (render_structure_text,
                                           structure_report)
        print(render_structure_text(structure_report()))
        return 0
    if args.structure_json:
        from .repository_structure import structure_report
        print(json.dumps(structure_report(), indent=1))
        return 0
    if args.repo_conformance:
        from .repository_conformance import run_repository_conformance
        report = run_repository_conformance()
        print(json.dumps(report, indent=1))
        return 0 if report["passed"] else 1
    if args.architecture_contract:
        from .architecture_contract import run_architecture_contract_checks
        report = run_architecture_contract_checks()
        print(json.dumps(report, indent=1))
        return 0 if report["passed"] else 1
    if args.templates:
        from .templates.library import TemplateLibrary
        library = TemplateLibrary()
        print(json.dumps({
            "record_type": "task_templates/v1",
            "templates": [t.to_dict() for t in
                          (library.get(i) for i in library.ids())],
        }, indent=1))
        return 0
    if args.task_build:
        from .adaptive_practitioner_cli import run_task_build
        return run_task_build(args)
    if args.task_compile:
        from .cli_operations import run_task_compile
        return run_task_compile(args)
    if args.solve:
        from .solve_cli import run_solve
        return run_solve(args)
    if args.learn:
        from .cli_operations import run_learn
        return run_learn(args)
    if args.candidate_action:
        from .cli_operations import run_candidate_action
        return run_candidate_action(args)
    if args.candidates:
        from .memory.storage.repository import CandidateJournal
        journal = CandidateJournal()
        candidates = journal.list_candidates()
        print(json.dumps({
            "record_type": "learning_candidates/v1",
            "storage": str(journal.journal),
            "candidates": candidates,
            "note": ("no candidates staged; run --learn first"
                     if not candidates else
                     f"{len(candidates)} candidate(s) staged; each awaits "
                     "independent review"),
        }, indent=1))
        return 0
    if args.demo == "five-step":
        from .cli_operations import run_five_step_demo
        return run_five_step_demo(args)
    if args.map:
        from .architecture_map import render_map as render_architecture
        print(render_architecture())
        return 0
    if args.profiles:
        from .loop.loop_profile_catalog import (
            PROFILE_ONTOLOGY_VERSION, profile_catalog)
        profiles = profile_catalog()
        print(json.dumps({
            "record_type": "loop_profile_catalog/v1",
            "ontology_version": PROFILE_ONTOLOGY_VERSION,
            "profiles": profiles,
        }, indent=1))
        return 0
    if args.categories:
        print(json.dumps({"resolver_categories": [],
                          "default_levels": {},
                          "move_types": []}, indent=1))
        return 0
    if args.self_test or args.self_test_verbose:
        if args.self_test_verbose:
            report = self_test()
            print(json.dumps(report, indent=1))
        else:
            print(
                "Running the full offline self-test. This scans the installed "
                "package and may take about a minute. No provider is called.",
                file=sys.stderr, flush=True)
            started = time.monotonic()
            report, captured_lines = _run_self_test_captured()
            summary = _concise_self_test_summary(
                report, captured_lines, time.monotonic() - started)
            if args.format == "json":
                print(json.dumps(summary, indent=1))
            else:
                print(_render_self_test_summary(summary))
        return 0 if report["all_passed"] else 1
    parser.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())

# Development checkpoints

Dated, versioned snapshots of the entire system state. Each checkpoint
captures the architecture, tests, conformance, and evidence at one
moment so any later session can reconstruct exactly what existed.

These are historical records, not current status or instructions to rerun a
campaign. Preserve their recorded revisions and failed checks. The current
session entry point is [START-HERE.md](../docs/context/START-HERE.md).

## Layout

```text
checkpoints/
├── README.md
└── <date>-<slug>/
    ├── SNAPSHOT.md          human-readable system summary
    ├── state.json           machine-readable state
    ├── tree.txt             full repository tree
    ├── test-report.json     self-test results
    ├── conformance.json     conformance gate results
    └── git-state.txt        branch, commit, and dirty state
```

## Legacy checkpoint helper

`tools/make_checkpoint.py` is retained as historical development tooling.
Inspection on September 13, 2026 found that it expects the old self-test
output shape, combines command output without preserving return codes,
allows an existing target directory, and lists a `conformance.json` file
that it does not write. Its tracked-file listing is not a complete snapshot
of this dirty workspace. Its slug is not path-confined.

Do not use this helper as the current verification or review-packet writer
until those defects are repaired and tested. This warning does not change
historical checkpoint files. Generated structured records must use DuckDB
or an established managed writer. Any replacement should preserve command
return codes, exact source identities, failed attempts, exclusive output
creation, and path confinement. Do not create another Run History store.

Existing committed checkpoints remain evidence. Creating a new checkpoint
does not authorize committing or publishing it.

# Reference mirrors

These archives preserve exact source states for independent inspection and preparation. They are not merged into the product import graph or promoted to executable Code Intelligence. An original repository can continue evolving without changing a frozen mirror.

| Folder | Source and purpose |
|---|---|
| [new_overnight_build](new_overnight_build/) | Adaptive steps, structured patch tool, distillation and replay |
| [overnight](overnight/) | Repair and recursive solvers, horizons, transports and memory |
| [vigil](vigil/) | CI intake, quarantine, regression gates and branch delivery |
| [speculative_prompting](speculative_prompting/) | TypeScript local agent and control-plane interfaces |
| [overnight_docs](overnight_docs/) | Historical briefs, audits and context experiments |

The snapshot command excludes dirty changes, runtime records, databases, `.env` files, credentials, dependency caches, distributions and build output. The provenance manifest records every included file digest and every excluded tracked path. Source archives include the original licenses where present. Their presence is not a licensing or security qualification for redistribution or execution.

The mirror preparation tool refuses overwrite, traversal, symlinks, unexpected members, digest drift and oversized expansion. Preparation creates source files but does not install dependencies, call a provider, run a model, start a service or publish anything. It is an explicit review step before selecting a qualified external harness profile.

Prepared workspaces must be outside the Loop Engine repository. The frozen archives remain in these folders; extracted foreign runtimes and historical vocabulary are not first-party product source. This boundary is enforced by the preparation command.

Other discovered candidates include the independent Ollama Loop Behavior Lab, `universal-node-graph-flexible-solutioning-gpt/solutiongraph`, and `this-already-exists-dont-rebuild-it`. They remain research candidates until their boundaries and licenses are inspected. Taedri remains a semantic design reference under the repository's existing reference-source rules.

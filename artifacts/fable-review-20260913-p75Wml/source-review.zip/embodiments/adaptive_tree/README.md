# Adaptive decomposition

Status: `planned`. Runtime type: `Loop`.

Attempt first, then select a contract-bound decomposition after verified failure.

Not connected to this lab yet; use the existing PoC only as design evidence.

This folder is an independent launch surface. It shares task contracts, evaluator and canonical runtime with the other embodiments so comparisons remain meaningful. Its state and run artifacts live only in the output directory you select.

Running the entry point returns a typed unavailable result. This prevents a planned folder from being mistaken for working code. The next step is an exact adapter, positive and adversarial fixtures, an observed effect record, and a separately authorized live comparison.

See [the comparison index](../README.md), [architecture contract](../ARCHITECTURE.md), and [research and build plans](../../artifacts/review-2026-09-07/README.md).

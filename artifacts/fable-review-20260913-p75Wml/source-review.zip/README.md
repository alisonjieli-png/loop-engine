# Building with Loops

Loop Engine coordinates tasks through one shared Loop runtime. Given configured
capabilities and authority, it attempts the work, checks the results, and saves
completed work and failures in an inspectable Run History.

It takes small steps and selects the next concrete action itself. It records
typed model decisions and material actions, then checks its work before
claiming success. Verified code, context, and solutions can become candidates
for governed reuse.

The built-in quickstart builds small Python projects. Other applications can
supply their own operations and verification through the
[host integration API](docs/guides/embedding-loop-engine.md). The host controls
its files, commands, repository, and acceptance gates; the Loop reasons over
the available capabilities and their observations. This interface is not a
claim that arbitrary unseen tasks are already solved.

## Solve with human-like loops

Download the first example task and run the LLM-first quickstart profile. The
Practitioner reads the task, selects the next concrete action, runs Solution
Loops in a confined workspace, and verifies the real artifacts:

```bash
curl -LO \
  https://raw.githubusercontent.com/alisonjieli-png/loop-engine/main/examples/tasks/01-expense-report.txt

loop-engine solve --file 01-expense-report.txt --quickstart
```

If the selected hosted model is temporarily unavailable, permit another exact
route for the same configured provider on the same solve path:

```bash
loop-engine solve --file 01-expense-report.txt --quickstart \
  --allow-model-failover
```

An explicitly selected `--model-id` remains pinned. Failover does not bypass
authentication, request, permission, effect, output, or verification checks.

`--quickstart` is an explicit authority profile. It selects one configured
provider, starts the LLM-first Practitioner, asks material
questions when needed, and permits the existing confined Docker workspace. It
does not impose a numeric pass, model-call, or token ceiling unless the user or
settings provide one. It does not authorize deployment, publication, or network
access from generated code.

The Practitioner reads the task, asks a material question when an answer would
change the goal, selects the next concrete action, runs Solution Loops in a
confined workspace, and verifies the real artifacts. Users do not choose
deterministic, hybrid, or model-led execution during the normal solve path.
The runtime selects model-led reasoning when a model is available. Use
`--unattended` only when a run must abstain instead of returning a material
question.

Perspectives, question sets, templates, Intelligence refs, prior solutions,
and recovery strategies enter the prompt as candidates. The model selects
among them. Scores and step affinity help comparison but do not choose a task
meaning or solution.

Task interpretation is not limited to a fixed list or template. The current
effect capabilities can build small Python utilities, transform supplied local
files, summarize documents, analyze repositories, and repair small Python
packages. A task that needs another physical capability returns an honest
`CAPABILITY_GAP`.

A successful result has this shape:

```text
COMPLETED_VERIFIED
Expense report command and verified Markdown output.

Artifacts:
  .../workspace/attempt-1/expense_report.py (verified)
  .../workspace/attempt-1/report.md (verified)

Workspace: .../<run-id>-workspace/attempt-1
Verification: passed
Run ID: <run-id>
Run History: ~/.loop-engine/runs/<run-id>
```

A generated-project solve writes only inside the selected workspace. Commands
run in the pinned Docker image with bounded resources and no network during
execute or verify steps. Dependency setup requires separate authority. If
Docker is absent, the solve stops with a typed sandbox-unavailable result
unless you pass `--allow-local-execution`, which runs generated code as a host
process without an operating-system sandbox and records that weaker isolation
in Run History.

If an answer can materially change the goal, authority, inputs, or acceptance,
the solve returns `BLOCKED_MATERIAL_INPUT` with a named answer slot instead of
guessing. Supply the answer separately and rerun the unchanged task:

```bash
loop-engine solve --file task.txt --quickstart \
  --task-feedback 'required_destination=./results/final-report.md'
```

Read [LLM-first universal solving](docs/guides/llm-first-universal-solver.md)
for the model/runtime boundary.

## Compare experimental embodiments

The [embodiment catalog](embodiments/README.md) preserves alternative ways to
build and run Loop Engine applications. Each design has its own folder,
launcher, manifest, tradeoffs, and qualification status. Current runnable
experiments compare native execution, fresh processes, persistent sessions,
session pools, parallel portfolios, and durable reactive work with a trusted
deterministic backend. They do not claim live model or harness qualification.
Additional designs remain explicitly planned. No single embodiment is selected
as the winner for every project.

Local `solver-lab` project copies have their own source, evaluators,
dependencies, and run state. Their filesystem location is host-specific;
they are not part of the Loop Engine distribution. Follow the
[reference-source boundaries](docs/context/REFERENCE-SOURCES.md) before
consulting an older copy. Experiments in this repository continue to share
the canonical Loop runtime.

## Reuse verified work

A careful colleague takes notes and remembers. Loop Engine saves more than the
final answer: verified code, reusable context, and complete solutions all
become candidates for the next run. After an accepted generated implementation,
it can emit a small reuse opportunity and return the source result without
waiting for packaging. The asynchronous harvest path creates a Code
Intelligence candidate. A future task can use it only after independent
qualification and explicit promotion. An exact promoted match executes
deterministically with zero model calls.

A versioned Loop contract may also execute without a dedicated conventional
implementation body. The exact semantic specification is bound into its
`LoopDefinition`. A qualified interpreter produces an untrusted candidate,
then independent verification and effect control decide whether anything may
enter trusted state. A later promoted deterministic realization can satisfy the
same contract with zero model calls for its declared input region. Read
[Transactional semantic runtime](docs/components/loop-object/SEMANTIC-RUNTIME.md).

Read the
[Reusable Capability Flywheel](docs/components/intelligence-layers/REUSABLE-CAPABILITY-FLYWHEEL.md)
for candidate harvesting, promotion, search, and deterministic reuse.

An offline research foundation now computes candidate diagnostics that compare
a compact state with history and records procedural-memory probes for control
boundaries that safe reuse would need. The strongest procedural status remains
pending canonical reference resolution. These records cannot select or promote
a procedure. A separate offline public-solve fixture now exposes hydrated
prior-stage material to a prompt-sensitive provider adapter and links one
action stage through exact selection, execution, and verification occurrence
references. Its pre-run control manifest is saved before model work and says
`mechanism_only` because six controls remain unresolved. It uses injected
responses, so no live-model quality or assistance benefit is claimed. See the
[procedural-memory and predictive-state note](docs/research/PROCEDURAL-MEMORY-PREDICTIVE-STATE-AND-INFORMATION-VALUE-2026-09-04.md)
and the
[current offline verification report](docs/verification/PREDICTIVE-STATE-PROCEDURAL-MEMORY-AND-STAGE-ASSISTANCE-2026-09-04.md).

## How it works

```text
Original task
└─ Starting Practitioner Loop
   ├─ orient and standardize
   ├─ select the next concrete action
   ├─ propose a registered capability or a new local implementation
   ├─ validate permissions and capability availability
   ├─ run Solution Loops in a confined workspace
   ├─ inspect commands and artifacts
   └─ return one terminal result with Run History
```

Every executable graph position uses the same runtime type, `Loop`.
Practitioner, Intelligence, and Solution are roles. Deterministic, hybrid, and
non-deterministic are per-Loop modes. `LoopGraphDefinition` remains the one
executable graph authority.

Read [how Loop Engine works](docs/guides/how-it-works.md) after the quickstart.
The [Architecture Constitution](docs/architecture/CONSTITUTION.md) defines the
hard runtime, permission, evidence, and governance rules.

## Install

You need [Python 3.10 or newer](https://www.python.org/downloads/) and
[Docker](https://docs.docker.com/get-docker/). Git is not required for the
quickstart. Starting from an empty computer? Use the
[Windows](docs/guides/install-windows/) or
[macOS](docs/guides/install-macos/) instructions first.

```bash
mkdir loop-engine-quickstart
cd loop-engine-quickstart

python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install \
  "https://github.com/alisonjieli-png/loop-engine/archive/refs/heads/main.zip"

docker pull \
  python@sha256:2407c61b1a18067393fecd8a22cf6fceede893b6aaca817bf9fbfe65e33614a3

loop-engine doctor
```

The default install is lightweight. In a source checkout, install `.[data]`
for the larger ML, Kaggle, vector, and analytical adapters, or `.[all]` for
every first-party optional adapter. The base self-test reports optional
adapters as not tested; it does not misreport a lightweight installation as
broken.

## Configure one provider

The shortest hosted path uses Ollama Cloud. Set the key, then inspect the
configuration without making a provider call:

```bash
export OLLAMA_API_KEY="your-key"
loop-engine configure
```

Check the exact route with one authorized call:

```bash
loop-engine models probe ollama_cloud \
  --model-route cloud.default \
  --model-id deepseek-v4-flash:0731 \
  --authorize-model-calls \
  --max-model-calls 1 \
  --max-total-tokens 70000
```

Do not continue if the probe reports authentication, rate-limit, output-limit,
or availability failure. A configured key is not proof that a provider works.

See [providers and keys](docs/guides/providers-and-keys.md) for OpenRouter,
Mistral, local Ollama, OpenCode Go, and custom endpoints.

If you have an OpenRouter key and want a current zero-price route, export the
key and add `--openrouter-api-key` to `solve`. Loop Engine reads OpenRouter's
live catalog, selects an exact zero-price structured model with a declared
output maximum, and freezes that route for the run. `--opencode-zen-api-key`
does the same for current compatible OpenCode Zen zero-cost models.

If several known provider keys are present, quickstart prefers the dynamic
zero-price OpenRouter route, then the zero-cost OpenCode Zen route, before the
fixed Ollama Cloud, Mistral, and OpenCode Go routes. This chooses a candidate
route; it does not promise that the provider quota is currently available.

## Add providers and capabilities with files

Loop Engine automatically checks these optional folders:

```text
.loop-engine/extensions
~/.config/loop-engine/extensions
```

They may contain provider routes, capability candidates, skills, plugin
bundles, and plugin intelligence. Inspect everything without a provider call:

```bash
loop-engine extensions discover
loop-engine extensions providers --format json
```

Zero-price routes and local routes activate automatically when their required
configuration exists. Free-plan allowances and paid routes require
`--allow-paid-extension-routes` because billing may begin after a quota.
Dropped code and intelligence remain candidates until their existing admission
and review requirements pass.

See [added-file extensions](docs/architecture/ADDED-FILE-EXTENSIONS.md) and the
[complete example](examples/23_drop_in_extensions/). The
[provider endpoint landscape](docs/guides/provider-endpoint-landscape.md)
lists the protocol and authentication families, including native cloud APIs
that still need a reviewed adapter.

## Inspect the result

```bash
loop-engine runs
loop-engine report @last
loop-engine studio --port 0
```

Studio selects an available local port and prints the address. Open the Result
tab for artifacts and verification, Playback for the event sequence, Tree for
the Loop hierarchy, and Calls for provider activity.

Use JSON when another program consumes the result:

```bash
loop-engine solve \
  --file task.txt \
  --quickstart \
  --format json
```

JSON mode emits one machine-readable solve result with the terminal code,
artifact records, verification, model usage, tool count, workspace, and Run
History location.

## Query records and manage notes

One typed catalog query can read canonical JSONL rows, SQLite records, or the
optional DuckDB file adapter. Backend capabilities remain explicit. Readable
files do not become writable tables merely because SQL can query them.

`loop-engine records` manages scoped notes with schema validation, exact write
approval, immutable revisions, and atomic expected-version updates. It does
not expose raw SQL or let note content grant execution authority.
See [queryable records and storage](docs/guides/queryable-records-and-storage.md)
and the [managed-record example](examples/24_managed_records/).

This is a first local tool path. Existing file writers, generated session
Markdown, and a qualified PostgreSQL backend remain separate work.

## Solve from a task file

You can also [download ready-to-run task files](examples/tasks/) from GitHub.

```bash
cat > task.txt <<'EOF'
Create a Python command-line program that reads a JSON file, produces a
Markdown summary, and includes runnable verification.
EOF

loop-engine solve --file task.txt --quickstart
```

## Use a local dataset or repository

Local source content is not sent to a model without a separate grant.

```bash
loop-engine solve \
  --dataset ./inventory.csv \
  --text "Normalize product names, mark quantities of five or lower as low stock, and write a cleaned CSV plus a summary." \
  --allow-source-to-model \
  --quickstart
```

Use `--repository PATH --text "task"` for a document folder or small Python
package. The Practitioner first sees an input manifest. The model selects the
text files it needs, then Loop Engine materializes those exact files, excludes
common dependency and version-control folders, and records input digests.

## What is supported now

| Area | Current behavior |
|---|---|
| Small Python utilities | Model proposes typed files and commands. Docker executes and verifies them. |
| Local data transforms | Selected CSV, JSON, text, and related inputs can be copied into the workspace. |
| Document and repository analysis | Model-selected text files can be materialized with explicit source-to-model authority. |
| Source formats | Readable UTF-8 source is admitted by bounded content inspection, not a programming-language suffix list. Exclusions have explicit reasons. |
| Host-owned work | Python embedding API accepts registered host operations, scoped permissions, and a separate host verifier. Results need not be generated projects. |
| Small Python package repair | The run can reproduce a nonzero exit, apply a changed source artifact, and rerun verification. |
| Providers | Ollama Cloud, Mistral, OpenRouter, OpenCode Go, and typed custom endpoints. Availability must be probed. |
| Effects | Workspace writes and commands require configured sandbox authority and exact per-effect approval. |
| Unsupported work | Returns `CAPABILITY_GAP`, `AUTHORITY_REQUIRED`, `PROVIDER_UNAVAILABLE`, or another typed terminal result. |

Loop Engine does not yet claim arbitrary-domain execution, automatic
deployment, unrestricted shell access, broad repository repair, or guaranteed
model quality.

Host integration requires trusted adapter code, explicit permission to share
host output with a model, and host-enforced execution policy. It does not expose
unrestricted shell access or install a remote host automatically. The
[JavaScript repository example](examples/25_host_runtime/README.md) shows the
boundary using a populated project and fixed `npm test` gates.

The [tabular portfolio example](examples/25_host_runtime/TABULAR-PORTFOLIO.md)
uses the same binding to train model configurations selected by the engine.
Three live exercises on Titanic, house prices, and Iris produced 36 fitted
pipelines with separately scored holdouts. These are familiar-dataset local
evaluations, not unseen-task or Kaggle leaderboard results. See the
[complete model comparison](docs/verification/TABULAR-MODEL-PORTFOLIO-2026-09-06.md).

The [adaptive completion checkpoint](docs/verification/ADAPTIVE-COMPLETION-AND-PUBLICATION-2026-09-06.md)
tests optional host completion gates, typed serial dependency inputs, and
restart behavior that refuses to replay an unknown running effect. The
[exported-ticket example](examples/25_host_runtime/EXPORTED-TICKET-PILOT.md)
produces local review material; production Overnight/Jira integration remains
unproven. The [TrafficFlowBench capstone](docs/benchmarks/TRAFFICFLOWBENCH-NATIVE-OPENCODE-PLAN.md)
sets out the native/OpenCode comparison and its independent scoring boundary.

Optional harnesses use the same Loop boundary through explicitly registered
adapters. Missing tool, skill, isolation, or limit requirements cause refusal
before execution. The legacy OpenCode raw-host process adapter remains
quarantined. Separate brokered text-proposal execution and experimental
native Markdown loading have bounded evidence in the
[configuration report](docs/verification/CONFIGURATION-AND-NATIVE-INITIALIZATION-2026-09-12.md);
that evidence does not qualify unrestricted native tools or host execution.
See the [harness boundary](docs/components/core-architecture/MCP-AND-SKILLS.md#external-harness-boundary)
and [alternative harness review](docs/research/STORAGE-PACKAGES-HARNESSES-AND-MEMORY-2026-09-04.md#alternatives-to-opencode).
This does not disable OpenCode Go or Zen provider endpoints, which are separate
model adapters.

Every Loop exposes the same three-mode policy view through typed configuration:
deterministic, hybrid, and non-deterministic. Preferences and fallback order do
not grant permissions or install missing executors. Output capacity is also
separate from a chosen allowance. A reasoning Loop can use bounded failure and
history context to select an explicit `ModelOutputAllocation` for a retry;
without one, the request uses full known capacity. See
[reasoned output and mode policies](docs/verification/REASONED-OUTPUT-AND-MODE-POLICY-2026-09-05.md).
Strict total-token requests currently require a host-qualified exact-request
bound; a production route without one refuses before dispatch.

## Task build is not solve

```text
loop-engine task build
  -> understands and structures a task
  -> does not claim that requested artifacts exist

loop-engine solve
  -> performs permitted work
  -> verifies real artifacts or returns an honest blocker
```

## Development

```bash
python -m pip install -e '.[all]'
PYTHONPATH=src python -m loop_engine --self-test
PYTHONPATH=src python -m loop_engine --conformance
python -m build
```

Offline fixtures test typed semantic obligations but do not prove live model
quality. Live-provider claims require a separately saved authorized result.

## License

MIT. See [LICENSE](LICENSE).

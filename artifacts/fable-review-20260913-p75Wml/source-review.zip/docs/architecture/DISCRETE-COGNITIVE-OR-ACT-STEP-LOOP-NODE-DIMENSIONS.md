# Discrete cognitive or act step Loop node: configuration dimensions

The owner confirmed this requirement on September 13, 2026: every discrete
cognitive or act step Loop node needs an explicit initial configuration and
ordered fallback priorities across the complete dimension set below.
Harness and model choice are only two parts of that configuration.

This is an accepted design requirement, not a claim that automatic selection,
fallback, or live qualification already covers every dimension. The
machine-readable requirement is under `loop_dimensions.configuration_design`
in [architecture.yaml](../../architecture.yaml). It is a design inventory,
not an executable configuration format or permission grant.

## Complete explanation

A discrete cognitive or act step Loop node is an independently governed
instance of the Loop runtime responsible for one clearly defined cognitive
step or action. A cognitive step might interpret information, identify a
missing requirement, compare alternatives, or evaluate a result. An action
might inspect a directory, build software, execute a test, create an artifact,
or send an authorized email.

Each discrete cognitive or act step Loop node receives the context,
instructions, skills, plugins, tools, and working files relevant to its
assignment. Essential information can be supplied directly, while additional
information can remain in centralized storage behind authorized, versioned
references. It does not automatically need the entire task history or every
available tool.

A separately initialized harness process, such as OpenCode, Pi, Codex, or a
custom implementation, can perform the assignment. When explicitly permitted,
another harness can attempt the same assignment after a failure. The
assignment's contracts, permissions, history, and remaining authority persist
across those attempts.

Discrete describes the scope of the assignment, not a restriction to one
attempt, one model call, or one output. A discrete cognitive or act step Loop
node can examine whether an observation matches its expectations, identify a
problem, repair or change its approach, and repeat until its declared
completion conditions are satisfied.

Alternatively, a discrete cognitive or act step Loop node can publish an
initial candidate output and continue working while its continuation
conditions and authority permit. It can produce additional alternatives over
time, including alternatives that are better, worse, or useful under different
circumstances. Consumers must identify exactly which output they used.
Publishing an output does not necessarily mean that the producing assignment
has finished.

For externally consequential actions, continued operation does not authorize
repeated effects. For example, generating alternative email drafts can
continue, but sending an email requires its own authorization and protection
against duplicate delivery.

That complete explanation must remain alongside the full phrase. A shorter
label alone is not an adequate replacement.

The explanation is preserved from the
[September 12 session handoff](../context/DISCRETE-COGNITIVE-OR-ACT-STEP-LOOP-NODE-HANDOFF-2026-09-12.md).

## Runtime classification

```text
Operational runtime type
└── Loop
    ├── Operational relationship
    │   ├── Starting
    │   ├── Spawned by
    │   ├── Queried by
    │   ├── Retrieved by
    │   └── Connected from
    ├── Role
    │   ├── Practitioner
    │   ├── Intelligence
    │   └── Solution
    ├── Versioned role profile
    ├── Purpose and domain categories
    ├── Run mode
    │   ├── deterministic
    │   ├── hybrid
    │   └── non-deterministic, with model-led semantic work
    ├── Step profile
    ├── Typed input and output contract
    ├── Loop condition
    ├── Exit condition
    ├── Graph relationships
    ├── Budget, permissions, and effect policy
    ├── Model settings when the selected mode permits a model
    └── Run History records
```

The phrase describes an executable graph vertex implemented by the canonical
`Loop`. It does not create a runtime class, role, mode, or `Node` subclass.
Tools, skills, plugins, hooks, contracts, and harness adapters are resources
or mechanics used by a Loop. They are not additional executable vertices.

The owner's phrase "starting harness" means the initial harness choice for
an assignment. It does not change whether the owning Loop is Starting,
Spawned by, Queried by, Retrieved by, or Connected from another Loop.
Practitioner style is a versioned role profile and step configuration, not
another runtime type. The same configuration discipline applies to
Intelligence and Solution responsibilities where their profiles permit it.

```text
Loop role profiles
├── Practitioner
│   ├── reference nine-step
│   ├── compact five-step
│   ├── research
│   ├── solver
│   ├── verifier
│   ├── code execution
│   └── self-improvement task
├── Intelligence
│   ├── cross-layer search and materialize
│   ├── Context Intelligence
│   │   └── serve, search, and frame
│   ├── Code Intelligence
│   │   └── resolve, invoke, and load
│   ├── Runtime History and Solution Intelligence
│   │   └── search, replay, and compare
│   └── User Feedback Intelligence
│       └── serve, scope, and interpret
└── Solution
    ├── atomic component
    ├── pipeline
    ├── router and fallback
    ├── ensemble
    └── validator
```

## Complete dimension set

Every row has its own initial choice and ordered fallback priorities. An
initial choice can be a set or a policy, not just one item. For example, an
assignment may need several tools together, with separate alternatives for
each required capability. An explicitly empty set is a valid initial choice
when the assignment needs no resource of that kind.

| Dimension | Initial configuration to record | Ordered fallback priorities to record |
|---|---|---|
| Harness implementation and process initialization | Custom implementation, native Practitioner, Pi, OpenCode, Codex, or another explicitly registered adapter; exact version, launch settings, process lifetime, and supported mechanics | Eligible alternative adapters or initialization recipes; trigger for each switch; state transferred, state discarded, and fresh-process requirements |
| Practitioner style or other role profile | Exact versioned role profile, supported responsibility, and required executor | Compatible profile alternatives that preserve the assignment contract; a changed role or responsibility requires a new governed definition |
| Step profile | Atomic, compact, reference nine-step, or custom ordered steps with repetition rules | Permitted changes to step order, decomposition, or repair procedure, with their own validation |
| Model | Preferred exact model identity and version where available; whether preference is configured or supported by matched evidence | Ordered eligible alternative models, with a separate reason and permission for each change |
| Provider and route | Exact provider, endpoint route, model binding, and credential reference | Same-provider alternatives and cross-provider failover priorities kept separate; cross-provider failover disabled unless explicitly authorized |
| Tools | Initial tool set, exact typed contracts, versions, effects, access scope, and required versus optional status | Alternatives per required capability and compatible tool combinations; no silent replacement by an unqualified tool |
| Skills | Initial reviewed skills, exact versions and digests, invocation conditions, and materialization policy | Ordered eligible skill alternatives or an explicit no-skill path when the contract permits it |
| Context Markdown files | Initial relevant context files, exact revisions, provenance, trust state, placement, and loading order | Alternative files or authorized retrieval sources; explicit behavior when a required file is absent, stale, or too large |
| Harness-native instruction Markdown files | Explicitly supported instruction filenames, scope, precedence, exact content, and loading mechanism | Ordered supported instruction files or initialization mechanisms; verify actual loading, not file presence |
| Prompt-injected Markdown and prompt construction | Selected Markdown bodies or references, placement in the prompt, trust separation, template version, and size policy | Permitted prompt templates, framing, materialization, or reference strategies; preserve task constraints and instruction authority |
| Plugins | Initial registered plugin set, exact handshakes, dependencies, compatibility, and effects | Ordered compatible plugins or built-in capabilities; installation and additional access require their own authority |
| Hooks | Initial lifecycle hooks, exact trigger points, order, contracts, failure policy, and effects | Compatible alternate hooks or a permitted no-hook path; mandatory approval or verification hooks cannot be bypassed |
| Input contract | Typed ports, schemas, semantic constraints, cardinality, provenance, and exact input references | Authorized alternate sources, encodings, or explicit adapter Loops; no silent weakening of required inputs |
| Output contract | Typed ports, schemas, semantic checks, cardinality, exact output identity, and consumer bindings | Compatible encodings or explicit adapter Loops; an alternative answer still has to satisfy the required contract |
| Supervisors and independent verifiers | Supervising Loop references, observation rules, evaluator contract and version, independence requirements, and escalation authority | Ordered qualified supervisors or verifiers and escalation paths; unavailable independent review cannot become self-approval |
| Thinking power | Model-supported thinking setting or explicit unsupported state, bound to the selected model route | Ordered supported thinking settings with decision evidence and remaining authority; increased thinking does not grant more effects |
| Model-call strategy | Whether model calls are needed, call purpose and sequencing, permitted retry, formatting repair, evaluator-triggered repair, and model comparison | Ordered alternate call strategies with distinct triggers; count every physical model call, including failures and harness changes |
| Model generation settings | Temperature and other settings actually supported by the exact provider and model | Ordered supported setting changes with their intended purpose; do not silently send unsupported settings |
| Model output allocation | Source-backed exact output capacity, selected allowance, allocation evidence, and unknown state when capacity is unavailable | Alternative authorized allocations within the known capacity; never invent a provider limit from a total budget or text estimate |
| Loop usage and orchestration | Assignment granularity, repetitions, nested governed work, relationship semantics, scheduling, concurrency, and permitted process reuse | Ordered changes to decomposition, repetition, scheduling, or authorized alternative attempts; each independently governed assignment remains a Loop |
| Run mode | Deterministic, hybrid, or non-deterministic, constrained by the profile, installed executor, and exact model authority | Ordered permitted mode alternatives; no mode change grants model, network, file, spending, or external-effect permission |
| Intelligence and Runtime Memory | Selected sources from the four persistent intelligence layers; separate run-scoped Runtime Memory; retrieval, selection, framing, and reference policies | Ordered authorized sources and access strategies; selection precedes large-body loading, and retrieved content remains data |
| Workspace and execution environment | Confined paths, declared sandbox, dependencies, installed runtimes, network policy, resource limits, and cancellation behavior | Ordered qualified environments or execution placements; failure never authorizes raw-host execution |
| Budgets, permissions, and effect policy | Separate time, model-call, token, spending, Loop-usage, file, network, secret, and external-effect authority; explicit unknown or unbounded states where allowed | Permitted narrower allocations or explicit escalation; fallback cannot replenish spent authority or manufacture a new grant |
| Loop condition, exit condition, and output publication | Conditions for continuing, repairing, completing, or stopping; early publication, additional candidates, and exact consumer selection | Ordered permitted recovery or escalation paths; terminal history remains terminal, and publishing a candidate is not acceptance or completion |

Instruction-file examples include `claude.md`, `CLAUDE.md`, `codex.md`, and
`AGENTS.md` where the selected harness or explicit initialization recipe
supports them. These filenames are not interchangeable. This requirement
does not assert that any harness automatically reads every listed filename.
A file's name never grants authority. Native loading and prompt injection
must be recorded and tested separately.

The four persistent intelligence layers are Context Intelligence, Code
Intelligence, Runtime History and Solution Intelligence, and User Feedback
Intelligence. Markdown files, skills, repositories, and vectors are source
formats, not extra intelligence layers. Runtime Memory is temporary and
scoped to one run.

## Required choice and fallback record

For each dimension, a resolved configuration must distinguish:

1. The initial value, exact versioned identity or immutable content reference,
   and the source of the choice.
2. Required, optional, explicitly absent, unsupported, and unknown states.
   Missing configuration must not masquerade as a deliberate empty set.
3. Ordered fallback priorities, including an explicit no-fallback decision
   when there is no permitted alternative.
4. Eligibility and compatibility with every other selected dimension, the
   assignment's typed contracts, and the installed executor.
5. The observation that permits each transition, the expected effect of the
   change, and which settings must remain fixed.
6. The exact authority and remaining resources required before transition,
   including approval for changed external effects.
7. The comparison objective, independent evaluation method, evidence
   references, uncertainty, and the reason for selection or refusal.
8. The attempted value, observed outcome, failure disposition, physical model
   calls, known token usage, elapsed time, and cost state in Run History.

These are requirements for typed contracts at existing owning boundaries.
They are not permission to interpret this document as a configuration object,
create a parallel registry, or infer executable behavior from prose.

Initial priorities and fallback priorities can differ. A fast initial choice
may be unsuitable after a particular semantic failure. A fallback can change
one dimension or an explicitly compatible combination. A failed instruction
load does not necessarily require a different model. A provider outage does
not necessarily require different task inputs. Record the actual change.

## Selection, evaluation, and safe transitions

The intended decision sequence is:

```text
Typed assignment, contracts, and authority
  -> effect-free discovery
  -> eligibility and compatibility checks
  -> comparison using applicable reviewed evidence
  -> initial configuration selection
  -> authorized materialization and initialization
  -> execution owned by the canonical Loop
  -> structural checks and independent semantic evaluation
  -> continue, publish, complete, refuse, or select a permitted fallback
  -> preserve the attempt and decision in Run History
```

"Preferred" can mean an owner-configured choice. "Most optimal" requires a
declared objective and evidence for the exact assignment population and
configuration. No harness or model is universally best. When evidence is
missing or incomparable, retain an explicit configured preference or return
an unknown selection result. Do not invent a learned ranking.

Keep same-configuration retry, changed settings, harness fallback,
same-provider model fallback, cross-provider failover, formatting repair,
evaluator-triggered repair, and task replanning distinct. An unavailable
evaluator is not a passing evaluation. A response that satisfies its schema
can still be wrong.

Switching configuration must preserve the task identity, exact inputs and
output commitments, authority already consumed, prior failures, and relevant
Run History. Reusing a process must not leak another assignment's resources
or permission state. Reinitialization must not reset a deadline or budget.
An uncertain external-effect outcome requires reconciliation before retry;
a fallback must not send a second email or repeat another committed effect.

Every input or output contract change needs explicit compatibility checks.
Do not lower the acceptance standard because a harness cannot satisfy it.
A supervisor replacement must preserve independent review. A model-generated
configuration or a successful trial remains candidate-only until the
existing independent process approves it for reuse.

## Testing and implementation status

Qualification must measure both individual dimensions and their interactions.
Freeze real assignments, input identities, evaluator versions, allowed
effects, and the candidate configurations before a comparison. Record the
selection rule and the exact attempted and excluded denominators. Test the
initial choice, every permitted fallback trigger, refusal cases, and the
transition itself. A record saying that settings changed is insufficient;
verify that the selected settings reached the actual execution.

Separate harness-native resources from engine-mediated resources. Test absent
resources and disabled loaders as controls. Include incompatible combinations,
stale references, prompt injection, missing usage, exhausted authority,
unavailable supervisors, and effects with uncertain outcomes. Preserve all
failed and excluded attempts alongside successes.

The
[September 12 configuration report](../verification/CONFIGURATION-AND-NATIVE-INITIALIZATION-2026-09-12.md)
records 70 real Tactical model calls, a forty-cell repair matrix, and nine
native Markdown loading controls. Those experiments cover a bounded subset
of this design. They do not qualify automatic selection or every fallback
dimension.

The current working tree also contains typed harness selection from matched,
reviewed trial evidence and a separate deterministic response-evaluation
boundary. These are a narrower implementation than this design requirement.
Do not claim that they jointly optimize models, resources, supervisors,
contracts, thinking power, or Loop usage. General cross-task selection and
the complete live configuration-and-fallback matrix remain unproven.

Future handoffs, including the requested Claude Fable 5.1 review, must use
this dimension set and the complete behavioral explanation. A review must
identify which dimensions are implemented, locally tested, qualified with a
real provider, unsupported, or still planned.

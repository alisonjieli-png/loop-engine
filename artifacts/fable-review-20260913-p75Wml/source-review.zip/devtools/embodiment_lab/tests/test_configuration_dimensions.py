"""Protect the owner's design inventory without claiming runtime qualification."""
from pathlib import Path
import unittest

import yaml


REPOSITORY = Path(__file__).resolve().parents[3]
DOCUMENT = 'docs/architecture/DISCRETE-COGNITIVE-OR-ACT-STEP-LOOP-NODE-DIMENSIONS.md'
HANDOFF = 'docs/context/DISCRETE-COGNITIVE-OR-ACT-STEP-LOOP-NODE-HANDOFF-2026-09-12.md'
DIMENSIONS = (
    'harness_implementation_and_process_initialization', 'role_profile', 'step_profile',
    'model', 'provider_and_route', 'tools', 'skills', 'context_markdown_files',
    'harness_native_instruction_markdown_files', 'prompt_injected_markdown_and_prompt_construction',
    'plugins', 'hooks', 'input_contract', 'output_contract', 'supervisors_and_independent_verifiers',
    'thinking_power', 'model_call_strategy', 'model_generation_settings', 'model_output_allocation',
    'loop_usage_and_orchestration', 'run_mode', 'intelligence_and_runtime_memory',
    'workspace_and_execution_environment', 'budgets_permissions_and_effect_policy',
    'loop_exit_and_output_publication_conditions',
)


class ConfigurationDimensionDocumentationChecks(unittest.TestCase):
    def setUp(self):
        self.architecture = yaml.safe_load((REPOSITORY / 'architecture.yaml').read_text())
        self.design = self.architecture['loop_dimensions']['configuration_design']

    def test_complete_dimension_inventory_is_not_reduced_to_harness_and_model(self):
        self.assertEqual(tuple(self.design['dimensions']), DIMENSIONS)
        self.assertEqual(len(set(DIMENSIONS)), 25)

    def test_every_dimension_requires_initial_choice_and_ordered_fallback(self):
        required = self.design['required_per_dimension']
        self.assertIn('explicit_initial_choice_and_immutable_identity', required)
        self.assertIn('ordered_fallback_priorities_or_explicit_no_fallback', required)
        self.assertIn('eligibility_and_cross_dimension_compatibility', required)
        self.assertIn('exact_authority_and_remaining_resources', required)

    def test_design_is_explicitly_not_runtime_permission_or_qualification(self):
        self.assertFalse(self.design['executable_configuration'])
        self.assertEqual(self.design['status'], 'accepted_requirement_partially_implemented')
        self.assertEqual(self.design['operational_runtime_type'], 'Loop')

    def test_packaged_architecture_matches_authoritative_inventory(self):
        packaged = yaml.safe_load((REPOSITORY / 'src/loop_engine/data/architecture.yaml').read_text())
        self.assertEqual(packaged, self.architecture)

    def test_packaged_contract_files_preserve_exact_authoritative_bytes(self):
        for name in ('architecture.yaml', 'terminology.yaml'):
            self.assertEqual((REPOSITORY / name).read_bytes(),
                             (REPOSITORY / 'src/loop_engine/data' / name).read_bytes(), name)

    def test_complete_behavioral_explanation_is_preserved_verbatim(self):
        original = (REPOSITORY / HANDOFF).read_text().split('## Complete explanation\n\n', 1)[1]
        original = original.split('\n## Meaning of the existing runtime', 1)[0].strip()
        for name in (DOCUMENT, 'docs/context/CLAUDE-FABLE-5.1-REVIEW-HANDOFF-2026-09-13.md'):
            self.assertIn(original, (REPOSITORY / name).read_text(), name)

    def test_agent_entry_points_link_the_same_dimension_requirement(self):
        self.assertEqual(self.design['document'], DOCUMENT)
        self.assertEqual(self.design['behavioral_explanation'], HANDOFF)
        for name in ('AGENTS.md', 'docs/context/CODEX-START-HERE.md', HANDOFF):
            self.assertIn(Path(DOCUMENT).name, (REPOSITORY / name).read_text(), name)


if __name__ == '__main__':
    unittest.main()
